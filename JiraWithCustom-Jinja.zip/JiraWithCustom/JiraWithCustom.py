"""
This plugin extends support for adding fields to jira tickets created by Bots.
The Jira authentication configurations are handled outside this plugin
and referenced here.
NOTE: For Jira-cloud, 'password' is an API key, and for Jira-server, 'password' is
the password associated with the user.

Parameter-handling primitives are included in the plugin and used by the existing code.
These primitives cover the commonly-used data types and can be used to add additional fields
beyond what is implemented in the original plugin code.

In the Jira API, examining responses to
https://<jira api>/rest/api/2/field
and
https://<jira api>/rest/api/2/issue/<issue-id>
can provide useful information about the data types used for the jira fields
"""


from DivvyPlugins.plugin_jobs import PluginJob
from worker.registry import Router

import csv
import json
import logging

from jinja2 import Template
from jira import JIRA, JIRAError

from datetime import datetime
from DivvyBotfactory.event import BotEvent
from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyUtils import misc
from DivvyUtils.field_definition import (
    FieldOptions, BooleanField, StringField, Jinja2StringField, Jinja2TextField,
    TextField, SelectionField
)
from DivvyBotfactory.scheduling import get_noncompliant_resource_ids

logger = logging.getLogger('Jira Integration (With Custom Fields)')
registry = BotFactoryRegistryWrapper()

# List of defined priorities from Jira
PLUGIN_JIRA_PRIORITIES = [
    'Unprioritized',
    'Blocker',
    'High',
    'Medium',
    'Low'
]

# List of defined issuetypes from Jira.
# The Jira project may have been set up with different allowed types, and this
# list may need to be edited to add or remove valid issuetypes
PLUGIN_JIRA_ISSUETYPES = [
    'Bug',
    'Story'
]


@SharedSessionScope(DivvyCloudGatewayORM)
def get_jira_settings(organization_id):
    """
    Obtain the API and key values for the resource's organization
    """
    db = DivvyCloudGatewayORM()
    organization = db.session.query(DivvyDbObjects.Organization).get(organization_id)
    if not organization:
        raise ValueError("Unable to find organization")
    resource = organization.get_resource()

    # Get the API information for the payload
    username = resource.get_setting('divvy.jira.username')
    password = resource.get_setting('divvy.jira.password')
    server = resource.get_setting('divvy.jira.server')

    return username, password, server


def make_jira_connection(organization_id):
    username, password, server = get_jira_settings(
        organization_id=organization_id
    )
    if not username or not password or not server:
        raise ValueError(
            'Jira integration is not configured for this organization'
        )

    jira = JIRA(
        basic_auth=(username.get_typed_value(), password.get_typed_value()),
        options={'server': server.get_typed_value()},
        max_retries=0
    )

    return jira, server


def test_jira_settings(resource):
    """
    Obtain the required Jira connection settings via the resource's
    organization.
    """
    # Get the API information for the incident payload
    username = resource.get_setting('divvy.jira.username')
    password = resource.get_setting('divvy.jira.password')
    server = resource.get_setting('divvy.jira.server')

    try:
        JIRA(
            basic_auth=(username.get_typed_value(), password.get_typed_value()),
            options={'server': server.get_typed_value()},
            max_retries=0
        )
    except Exception:
        raise Warning(
            'Unable to communicate with the JIRA instance. Please validate '
            'credentials and connectivity to the server'
        )


# Parameter-handling primitives, covering the standard and commonly-used data formats
#
# Information about the data format for parameters can be found in the 'schema' information
# in the response to the https://<jira api>/rest/api/2/field REST call
# Additional useful information can be found by examining the response data for an
# individual ticket in Jira (https://<jira api>/rest/api/2/issue/<issue-id>)
# NOTE: The schema 'type' field is the most important for selecting which primitive to
# use, as the structure of the data, not its formatting, that defines which primitive to use
# Example data types that work with each primitive are provided below as reference.


def add_simple_param(param_key, param_value, issue_dict):
    """
    Add a simple parameter to the Jira ticket
    param_key : the name of the parameter (Ex: "project")
    param_value : parameter value (ex: "ENG")
    issue_dict : the dictionary of params/values for the Jira ticket
    Example field types:
    "schema": {
        "type": "datetime",...

    "schema": {
        "type": "string",...

    "schema": {
      "type": "number",..

    """
    issue_dict.update({
        param_key: param_value.strip()
    })
    return issue_dict


def add_keyed_param(param_key, param_value, param_value_key, issue_dict):
    """
      Add a  parameter to the Jira ticket, where the parameter is identified
      by an attribute key.
      For example: priority can be identified by 'id' or 'name'
      param_key : the jira key of the parameter (Ex: "priority")
      param_value_key : per-value parameter key (Ex: "name")
      issue_dict : the dictionary of params/values for the Jira ticket

      Example field types:
      "schema": {
        "type": "priority",...

      "schema": {
        "type": "status",...

      """
    c = {param_value_key: param_value.strip()}
    issue_dict.update({
        param_key: c
    })
    return issue_dict


def add_list_param(param_key, param_string, issue_dict):
    """
     Add a 'list' style parameter to the Jira ticket, where the list elements
     are values only with no attribute keys
     param_key : the jira key of the parameter (Ex: "labels")
     param_string : comma separated list of one or more item values (Ex: "AWS,Azure")
     issue_dict : the dictionary of params/values for the Jira ticket

     Example field types:
     "schema": {
       "type": "array",
       "items": "string",...

     """
    param_array = []
    param_list = param_string.split(",")
    for param_item in param_list:
        param_array.append(param_item)

    issue_dict.update({
        param_key: param_array
    })
    return issue_dict


def add_keyed_list_param(param_key, param_string, list_item_key, issue_dict):
    """
     Add a 'list' style parameter to the Jira ticket, where the list elements
     are each identified by an attribute key.
     For example: components can be identified by 'id' or 'name'
     param_key : the jira key of the parameter (Ex: "components")
     param_string : comma separated list of one or more item values (Ex: "Security,Product enhancement")
     issue_dict : the dictionary of params/values for the Jira ticket
     list_item_key : the "key" for the items in the list.

     Example types:
     "schema": {
       "type": "array",
       "items": "user",...

     "schema": {
       "type": "array",
       "items": "component",...
     """
    param_array = []
    param_list = param_string.split(",")
    for param_item in param_list:
        c = {list_item_key: param_item.strip()}
        param_array.append(c)

    issue_dict.update({
        param_key: param_array
    })
    return issue_dict


# this builds the dictionary of fields/values for creating an issue
def build_issue_dict(settings, event, resource):
    """
     Builds the dictionary of fields/values used for creating an issue in Jira
     This can be customized to add additional fields, which must also be added
     to the appropriate *_config[] field definition array below
    """
    # Parse summary/description
    # Note - Template()/render() is a flow that processes Jinja2 tags in the text that's
    #   passed in. Calling this with a field that has no Jinja2 tags has no effect, so
    #   it's safe to call for either version of the summary (with or without Jinja)
    summary_raw = Template(settings['summary'])  
    try:
        summary = summary_raw.render(event=event, resource=resource)
    except Exception as e:
        summary = "Unable to parse summary [{0}]".format(e)
        logger.exception(summary)

    # Note - Template()/render() is a flow that processes Jinja2 tags in the text that's
    #   passed in. Calling this with a field that has no Jinja2 tags has no effect, so
    #   it's safe to call for either version of the summary (with or without Jinja)
    description_raw = Template(settings['description'])
    try:
        description = description_raw.render(event=event, resource=resource)
    except Exception as e:
        description = "Unable to parse description [{0}]".format(e)
        logger.exception(description)


    project_raw = Template(settings['project'])
    try:
        project = project_raw.render(event=event, resource=resource)
    except Exception as e:
        project = "Unable to parse project [{0}]".format(e)
        logger.exception(project)

    print(project)

    

    # Create initial JIRA issue dict using baseline required fields
    issue_dict = {
        'project': project,
        'summary': summary,
        'description': description,
        'issuetype': settings['issue_type']
    }

    # process the components (optional) input
    component_string = settings['components']
    if len(component_string) != 0:
        issue_dict = add_keyed_list_param("components", component_string, "name", issue_dict)

    # process the labels (optional) input
    label_string = settings['labels']
    if len(label_string) != 0:
        issue_dict = add_list_param('labels', label_string, issue_dict)

    # Example of handling a custom field, for reference
    # This can be adapted to custom fields by examining the response from
    # https://<jira api>/api/2/field and selecting a parameter-handling
    # primitive compatible the field's schema
    #epic_string = settings['epic_link']
    #if len(epic_string) != 0:
    #    issue_dict = add_simple_param("customfield_10001", epic_string, issue_dict)

    issue_dict = add_keyed_param("priority", settings['priority'], "name", issue_dict)

    return issue_dict


def create_new_jira_ticket(bot, settings, jira, server, event=None, resource=None):
    """
     Creates a new jira ticket
    """
    issue_dict = build_issue_dict(settings, event, resource)
    ticket = None

    try:
        ticket = jira.create_issue(issue_dict)
        issue_dict.update({
            'id': str(ticket),
            'status': ticket.fields.status.name,
            'create_time': str(datetime.utcnow()),
            'html_link': '{0}/browse/{1}'.format(
                server.get_typed_value(), ticket.key
            )
        })

        bot.set_property(
            'jira.issue_info', json.dumps(issue_dict), 'json'
        ) 

    except Exception as e:
        message = "Unable to create ticket [{0}]".format(e.text)
        logger.warning(message)

    return ticket


# Field configuration arrays
# Summary and description fields, supporting Jinja, used for opening tickets on
# individual resources
jinja_summary_desc_config = [
        Jinja2StringField(
            name='summary',
            display_name='Summary',
            options=[FieldOptions.REQUIRED,FieldOptions.JINJA_PREVIEW],
            description='Brief title summary of the new issue (Jinja supported).'
        ),
        Jinja2TextField(
            name='description',
            display_name='Description',
            options=[FieldOptions.REQUIRED,FieldOptions.JINJA_PREVIEW],
            description='Details about the issue(Jinja supported).'
        ),
        Jinja2StringField(
            name='project',
            display_name='Project',
            description=(
                    'Name (Jira Key) of the project you would like to create the issue in. (Jinja supported) '
            ),
            options=[FieldOptions.REQUIRED, FieldOptions.JINJA_PREVIEW]
        ),
]
# Summary and description fields, supporting Jinja, used for opening tickets on
# a list of resources, where individual resource info is not available
plain_summary_desc_config = [

    StringField(
        name='summary',
        display_name='Summary',
        options=FieldOptions.REQUIRED,
        description='Brief title summary of the new task.'
    ),
    TextField(
        name='description',
        display_name='Description',
        options=FieldOptions.REQUIRED,
        description='Details about the issue and task.'
    ),
    StringField(
        name='project',
        display_name='Project',
        options=FieldOptions.REQUIRED,
        description=(
                'Name (Jira Key) of the project you would like to create the issue in.'
        )
    ),
]

# Settings fields that are common to both versions of tickets
common_settings_config = [
    StringField(
        name='components',
        display_name='Components',
        #options=FieldOptions.REQUIRED,
        description=(
                '(Optional) Name(s) of the component(s) you would like to create the task in. (comma-separated)'
        )
    ),
    StringField(
        name='labels',
        display_name='Labels',
        #options=FieldOptions.REQUIRED,
        description=(
                '(Optional) Name(s) of the label(s) you would like to add to the task. (comma-separated)'
        )
    ),
# Example of a custom field, see corresponding handling code in build_issue_dict()
#   StringField(
#       name='epic_link',
#       display_name='Epic Link',
#       #options=FieldOptions.REQUIRED,
#       description=(
#              '(Optional) Jira ID of the epic to link the issue to'
#       )
#   ),
    SelectionField(
        display_name='Priority',
        description=(
                'Choose the priority for the issue'
        ),
        choices=PLUGIN_JIRA_PRIORITIES,
        name='priority',
        options=FieldOptions.REQUIRED,

    ),
    SelectionField(
        name='issue_type',
        display_name='IssueType',
        options=FieldOptions.REQUIRED,
        choices=PLUGIN_JIRA_ISSUETYPES,
        description='Type of issue (e.g. Bug, Story, etc).'
    ),
    BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                    'When enabled, this will skip notification of resources which '
                    'are already marked noncompliant by this bot.'
            )
        )
]


@registry.action(
    uid='jira.action.create_task_with_custom',
    name='Create/Update Jira Issue (With CSV attachment) (With customization)',
    bulk_action=True,
    admin_only=True,
    description=(
            'Create an issue in the Jira portal. This will create the issue using '
            'the supplied credentials in the Jira integration settings.'
            ' Note that this action creates a single ticket per Bot and attaches a'
            ' CSV with all findings. This action is recommended for Bots that produce'
            ' a high volume of findings.'
    ),
    author='DivvyCloud',
    supported_resources=[],
    settings_config=plain_summary_desc_config+common_settings_config
)
def create_jira_task(bot, settings, matches, _non_matches):
    # This will only run if matches exist. Avoid creation a ticket for
    # not matches and an empty matches.
    if not matches:
        return

    db = DivvyCloudGatewayORM()
    skip_duplicates = settings.get('skip_duplicates', False)

    jira, server = make_jira_connection(organization_id=bot.organization_id)

    ticket_mapping_row = db.session.query(
        DivvyDbObjects.ResourceProperty.resource_id,
        DivvyDbObjects.ResourceProperty.value
    ).filter(
        DivvyDbObjects.ResourceProperty.name == 'jira.issue_info'
    ).filter(
        DivvyDbObjects.ResourceProperty.resource_id == str(bot.resource_id)
    ).first()

    filename = '/tmp/{0}-{1}.csv'.format(bot.name, datetime.utcnow().replace(
        microsecond=0, tzinfo=None
    ))

    # Perform a query to get the cloud account names. At scale this avoids
    # having to pull down a lot of extra data from the DB.
    cloud_accounts = {}
    for row in db.session.query(
            DivvyDbObjects.OrganizationService.organization_service_id,
            DivvyDbObjects.OrganizationService.name
    ):
        cloud_accounts[row.organization_service_id] = row.name

    # Build resource matches into a CSV that will be attached
    data = False

    #  From the stackoverflow article on how to write csv binary files in python3:
    #  https://stackoverflow.com/questions/5358322/csv-modules-writer-wont-let-me-write-binary-out
    with open(filename, 'w', newline='', encoding='utf8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([
            'Provider ID', 'Name', 'Region Name', 'Resource Type', 'Cloud Account'
        ])
        with NewSession(DivvyCloudGatewayORM):
            db = DivvyCloudGatewayORM()

            # Get a list of noncompliant resource IDs
            noncompliant_resource_ids = []
            if skip_duplicates:
                noncompliant_resource_ids = get_noncompliant_resource_ids(
                    db, bot.resource_id
                )

            resource_ids = [match.resource_id for match in matches]
            for chunk in misc.chunks(resource_ids, 1000):
                for row in db.session.query(
                        DivvyDbObjects.ResourceCommonData.resource_id,
                        DivvyDbObjects.ResourceCommonData.provider_id,
                        DivvyDbObjects.ResourceCommonData.name,
                        DivvyDbObjects.ResourceCommonData.region_name,
                        DivvyDbObjects.ResourceCommonData.resource_type,
                        DivvyDbObjects.ResourceCommonData.organization_service_id
                ).filter(
                    DivvyDbObjects.ResourceCommonData.resource_id.in_(chunk)
                ):
                    if skip_duplicates and str(row.resource_id) in noncompliant_resource_ids:
                        continue
                    data = True
                    writer.writerow([
                        row.provider_id,
                        row.name,
                        row.region_name,
                        row.resource_type,
                        cloud_accounts.get(row.organization_service_id)
                    ])

    if not ticket_mapping_row:
        # Create initial JIRA issue
        ticket = create_new_jira_ticket(bot, settings, jira, server)

    else:
        ticket_mapping = json.loads(ticket_mapping_row.value)
        try:
            ticket = jira.issue(ticket_mapping['id'])
        except JIRAError:
            # This ticket has been deleted or is no longer accessible.
            # We should create a new ticket.
            # Create initial JIRA issue
            ticket = create_new_jira_ticket(bot, settings, jira, server)

    # Only add the attachment to the ticket if we have matched resources
    if data:
        try:
            jira.add_attachment(issue=ticket, attachment=filename)
        except JIRAError:
            # This ticket has been closed and is no longer modifiable.
            # We should create a new ticket.
            # Create initial JIRA issue
            ticket = create_new_jira_ticket(bot, settings, jira, server)
            # Add the attachment now
            jira.add_attachment(issue=ticket, attachment=filename)


@registry.action(
    uid='jira.action.create_issue_with_custom',
    name='Create Individual Jira Issue (With customization)',
    bulk_action=True,
    admin_only=True,
    description=(
            'Create a JIRA issue for each resource identified by the Bot. '
            ' Note that this can result in a high volume of tickets.'
    ),
    author='DivvyCloud',
    supported_resources=[],
    settings_config=jinja_summary_desc_config+common_settings_config
)
def create_jira_issue(bot, settings, matches, _non_matches):

    # This will only run if matches exist. Avoid creation a ticket for
    # not matches and an empty matches.
    if not matches:
        return

    db = DivvyCloudGatewayORM()

    # Get a list of noncompliant resource IDs
    skip_duplicates = settings.get('skip_duplicates', False)
    noncompliant_resource_ids = []
    if skip_duplicates:
        noncompliant_resource_ids = get_noncompliant_resource_ids(
            db, bot.resource_id
        )

    jira, server = make_jira_connection(organization_id=bot.organization_id)

    for resource in matches:
        if skip_duplicates and str(resource.resource_id) in noncompliant_resource_ids:
            continue

        # Stubs event so templates are backwards compatible
        event = BotEvent(
            'hookpoint', resource, bot.bot_id, bot.name, bot.resource_id,
            bot.insight_id, bot.insight_name, bot.severity, bot.description
        )

        ticket = create_new_jira_ticket(bot, settings, jira, server, event, resource)


class JiraWithCustom(PluginJob):
    worker_name = 'JiraWithCustom'


def run(self):
    # This plugin doesn't 'run', it registers new bot actions (below)
    pass


def __repr__(self):
    return "JiraWithCustom()"


def register():
    args = {}
    Router.add_job(JiraWithCustom, args=args)


def unregister():
    pass


def load():
    # load the bot actions into the actions registry
    registry.load()
