import jinja2
import logging
import os
from datetime import date, datetime, timedelta

from DivvyApp.app_constants import Constants
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from DivvyUtils.mail import send_email
from DivvyUtils import schedule
from worker.registry import Router
from sqlalchemy import or_, and_

logger = logging.getLogger('InactiveUserScan')

FROM_EMAIL_ADDRESS = os.environ.get('INACTIVE_USER_PLUGIN_EMAIL_FROM')
EMAIL_RECIPIENTS = os.environ.get('INACTIVE_USER_PLUGIN_EMAIL_RECIPIENTS')

class InactiveUserScan(PluginJob):
    worker_name = 'InactiveUserScan'

    def process_notification(self, inactive_users):
        dir_name = os.path.abspath(os.path.dirname(__file__))
        html_template_path = os.path.join(
            dir_name + '/templates/user_report.html'
        )

        with open(html_template_path, 'r') as fp:
            email_template = fp.read()
            message_body = jinja2.Template(email_template)
            formatted_body = message_body.render(
                table_data=inactive_users,
                today=date.today().strftime('%B %d, %Y'),
                year=datetime.utcnow().year,
                main_logo=Constants.mapping['insight_pack_logo'],
                main_logo_alt=Constants.mapping['company_name'],
            )
            # Convert the EMAIL_RECIPIENTS  string to lists
            email_recipients_list = []
            if EMAIL_RECIPIENTS is not None:
                email_recipients_list = EMAIL_RECIPIENTS.split(',')
            
            if len(email_recipients_list) == 0:
                raise Warning(
                    'Recipient list is empty, not sending email'
                )


            send_email(
                subject='Inactive User Report For {0}'.format(
                    date.today().strftime('%B %d, %Y')
                ),
                message=None,
                from_email=FROM_EMAIL_ADDRESS,
                recipient_list=email_recipients_list,
                organization_id=1,
                html_message=formatted_body,
                inline_css=True
            )


    def run(self):

        if not FROM_EMAIL_ADDRESS:
            raise Warning(
                'Please supply the from email address environment variable'
            )
        if not EMAIL_RECIPIENTS:
            raise Warning(
                'Please supply the recipient list environment variable'
            )

        inactive_users = []
        threshold = datetime.utcnow() - timedelta(days=5)
        with NewSession(DivvyCloudGatewayORM) as session:
            users = session.query(
                DbObjects.User
            ).filter(
                DbObjects.User.authentication_server_id.isnot(None),
                DbObjects.User.suspended.is_(False),
                DbObjects.User.username.isnot(None),
                or_(
                    # older users don't have a create date, for these
                    # we currently don't disable if they've never logged 
                    # in because we might disable a brand new user
                    # (probably not an issue in a POC env)
                    and_(
                        DbObjects.User.create_date.is_(None),
                        DbObjects.User.last_login_attempt_time > '1970-01-01 00:00:01',
                        DbObjects.User.last_login_attempt_time < threshold,

                    ),
                    # Newer users have a create date, so for them check
                    # if the user has a create date older than the threshold and
                    # either has never logged in or hasn't logged in since
                    # the start of the threshold
                    and_(
                        DbObjects.User.create_date < threshold,
                        or_(
                            DbObjects.User.last_login_attempt_time < threshold,
                            DbObjects.User.last_login_attempt_time == '1970-01-01 00:00:01'
                        )
                    )
                )

            )
            inactive_userids = set()
            for row in users:
                inactive_users.append({
                    'username': row.username,
                    'email_address': row.email_address,
                    'last_login': row.last_login_attempt_time
                })
                inactive_userids.add(row.user_id)

            users.update(
                {'inactive': True, 'consecutive_failed_login_attempts': 0},
                synchronize_session=False
            )
            
            # remove deactivated users from groups

            user_group_query = session.query(
                DbObjects.UserGroupUser
            ).filter(
               DbObjects.UserGroupUser.user_id.in_(inactive_userids) 
            )
            user_group_query.delete(synchronize_session=False)

        if inactive_users:
            self.process_notification(inactive_users)

    def __repr__(self):
        return "InactiveUserScan()"


def register():
    args = {}
    Router.add_job(InactiveUserScan, args=args)
    scheduler_client.add_calendar_job(
        job=InactiveUserScan.__name__,
        args=args,
        schedule=schedule.Daily(schedule.TimeOfDay(hour=1, minute=0))
    )


def unregister():
    pass

def load():
    pass
