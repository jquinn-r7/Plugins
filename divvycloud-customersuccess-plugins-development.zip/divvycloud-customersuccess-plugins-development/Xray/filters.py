from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource import ResourceType
from DivvyUtils.field_definition import (
    SelectionField, FieldOptions, BooleanField
)

default_filters_author = 'DivvyCustom'


@QueryRegistry.register(
    query_id='custom.filter.xray_encryption_configuration_type',
    name='X-Ray Encryption Config Types',
    description=(
        'Returns the encryption configuration type used (default, KMS)'
    ),
    author=default_filters_author,
    supported_resources=[ResourceType.SERVICE_REGION],
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV
    ],
    settings_config=[
        SelectionField(
            name='type',
            choices=[('NONE', 'Default'), ('KMS', 'KMS')],
            display_name='Encryption Configuration Type',
            description='The type used for the encryption configuration',
            options=[FieldOptions.REQUIRED]
        ),
        BooleanField(
            name='in_use',
            display_name='In Use',
            description=(
                'When enabled, only match regions where Xray is in use'
            )
        )
    ],
    version='18.7'
)
def xray_encryption_configuration_type(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    config_type_subq = db.session.query(
        DivvyDbObjects.ResourceProperty.resource_id
    ).filter(
        DivvyDbObjects.ResourceProperty.name == 'custom.xray_encryption_config_type'
    ).filter(
        DivvyDbObjects.ResourceProperty.value == settings_config['type']
    )
    query = query.filter(db_cls.resource_id.in_(config_type_subq))

    if settings_config.get('in_use'):
        in_use_subq = db.session.query(
            DivvyDbObjects.ResourceProperty.resource_id
        ).filter(
            DivvyDbObjects.ResourceProperty.name == 'custom.xray_in_use'
        ).filter(
            DivvyDbObjects.ResourceProperty.value == '1'
        )
        query = query.filter(db_cls.resource_id.in_(in_use_subq))

    return query


def load():
    pass
