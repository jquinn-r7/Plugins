import boto3
import logging
from botocore.exceptions import ClientError
from datetime import datetime, timedelta

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import NewSession, SharedSessionScope
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyResource import ResourceIds
from scheduler import client
from worker.registry import Router

logger = logging.getLogger(__name__)


class XRayEncryptionConfigProcessor(PluginJob):

    def __init__(self):
        super(XRayEncryptionConfigProcessor, self).__init__()

    def get_xray_configuration(self, backend, db, region, org_service):
        client = boto3.client(
            'xray',
            aws_access_key_id=backend.auth_api_key,
            aws_secret_access_key=backend.auth_secret,
            aws_session_token=backend.session_token,
            region_name=region
        )

        encryption_type = client.get_encryption_config()['EncryptionConfig']['Type']
        resource_id = ResourceIds.ServiceRegion(
            organization_service_id=org_service.organization_service_id,
            region=region
        )
        db.session.merge(DivvyDbObjects.ResourceProperty(
            resource_id=resource_id,
            name='custom.xray_encryption_config_type',
            value=encryption_type,
            type_hint='string'
        ))
        # Identify if Xray is used
        in_use = False
        for group in client.get_groups()['Groups']:
            in_use = len(client.get_service_graph(
                StartTime=datetime.utcnow() - timedelta(hours=6),
                EndTime=datetime.utcnow(),
                GroupName=group['GroupName']
            ).get('Services', [])) > 0
            # if we find any group with X-Ray in use, we can drop out
            if in_use is True:
                break

        db.session.merge(DivvyDbObjects.ResourceProperty(
            resource_id=resource_id,
            name='custom.xray_in_use',
            value=in_use,
            type_hint='bool'
        ))
        db.session.commit()


    @SharedSessionScope(DivvyCloudGatewayORM)
    def run(self):
        """
        Job implementations must implement this method to perform their work
        """

        with NewSession(DivvyCloudGatewayORM):
            db = DivvyCloudGatewayORM()

            org_services = db.session.query(
                DivvyDbObjects.OrganizationService.organization_service_id,
                DivvyDbObjects.OrganizationService.name
            ).filter(
                DivvyDbObjects.OrganizationService.cloud_type_id == 'AWS'
            ).filter(
                DivvyDbObjects.OrganizationService.status.notin_([
                    DivvyDbObjects.OrganizationService.Status.DELETE,
                    DivvyDbObjects.OrganizationService.Status.PAUSED,
                    DivvyDbObjects.OrganizationService.Status.INVALID_CREDS,
                    DivvyDbObjects.OrganizationService.Status.ASSUME_ROLE_FAIL
                ])
            )

            for org_service in org_services:
                logger.info('Harvesting X-Ray encryption configuration for %s', org_service.name)
                frontend = get_cloud_type_by_organization_service_id(
                    org_service.organization_service_id
                )

                for region in frontend.get_compute_regions():
                    backend = frontend.get_cloud_gw(region_name=region)
                    try:
                        self.get_xray_configuration(
                            backend, db, region, org_service
                        )
                    except ClientError:
                        pass

def load():
    Router.add_job(XRayEncryptionConfigProcessor)
    client.add_periodic_job(
        XRayEncryptionConfigProcessor.__name__, args={}, interval=60 * 12
    )


def unload():
    pass
