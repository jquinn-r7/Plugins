from sqlalchemy import or_, and_, func

from DivvyDb import DivvyDbObjects as dbo
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import BooleanField, FieldOptions, BadgeField


default_filters_author = 'DivvyCloud'


@QueryRegistry.register(
    query_id='custom.query.resource_cross_account_account_by_badge',
    name='Resource Cross Account By Badge',
    description=(
        'Identify resources that have a share with an account that is not '
        'associated with the supplied badge.'
    ),
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[
        ResourceType.STORAGE_CONTAINER,
        ResourceType.SERVICE_ROLE,
        ResourceType.MESSAGE_QUEUE,
        ResourceType.NOTIFICATION_TOPIC,
        ResourceType.CONTAINER_REGISTRY,
        ResourceType.ELASTICSEARCH_INSTANCE,
        ResourceType.SERVICE_ENCRYPTION_KEY,
        ResourceType.REST_API,
        ResourceType.SECRET,
        ResourceType.COLD_STORAGE,
        ResourceType.NETWORK_ENDPOINT,
        ResourceType.SNAPSHOT,
        ResourceType.DATABASE_SNAPSHOT,
        ResourceType.PRIVATE_IMAGE,
        ResourceType.ACCESS_ANALYZER
    ],
    settings_config=[
        BadgeField(
            name='badges',
            display_name='Badges',
            description=(
                'Select the badge in question. Resources sharing to cloud '
                'accounts without this badge will be matched.'
            ),
            choices=[],
            options=[FieldOptions.REQUIRED],
        )
    ],
    version='20.4'
)
def resource_cross_account_account_by_badge(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    invalid_resource_ids = []
    whitelisted_accounts = []
    clauses = or_()
    for badge in settings_config['badges']:
        next_clause = and_(
            dbo.Badge.key == badge['key'],
            dbo.Badge.value == badge['value']
        )
        clauses = or_(clauses, next_clause)

    for row in db.session.query(
        dbo.OrganizationService.account_id
    ).filter(
        dbo.OrganizationService.resource_id.in_(
            db.session.query(dbo.Badge.target_resource_id).filter(clauses)
        )
    ):
        whitelisted_accounts.append(row.account_id)

    # Build our resource ID list. There's currently no easy way to do this
    # as a single MySQL query.
    if db_cls.resource_type not in [
        ResourceType.SNAPSHOT,
        ResourceType.DATABASE_SNAPSHOT,
        ResourceType.PRIVATE_IMAGE,
        ResourceType.ACCESS_ANALYZER
    ]:
        for row in db.session.query(
            db_cls.resource_id, db_cls.trusted_accounts
        ).filter(
            db_cls.trusted_accounts.isnot(None)
        ):
            if set(row.trusted_accounts) - set(whitelisted_accounts):
                invalid_resource_ids.append(row.resource_id)

    if db_cls.resource_type == ResourceType.ACCESS_ANALYZER:
        for row in db.session.query(
            dbo.AccessAnalyzer.resource_id,
            func.json_keys(dbo.AccessAnalyzer.account_mapping).label('account_mapping')
        ).filter(
            dbo.AccessAnalyzer.cross_account_count != 0
        ):
            if set(row.account_mapping) - set(whitelisted_accounts):
                invalid_resource_ids.append(row.resource_id)

    else:
        for row in db.session.query(
            dbo.SnapshotPermission.parent_resource_id,
            dbo.SnapshotPermission.trusted_accounts
        ).filter(
            dbo.SnapshotPermission.trusted_accounts.isnot(None)
        ):
            if set(row.trusted_accounts) - set(whitelisted_accounts):
                invalid_resource_ids.append(row.parent_resource_id)

    return query.filter(db_cls.resource_id.in_(invalid_resource_ids))


def load():
    pass
