import boto3
import json
import traceback
from datetime import datetime

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope
from DivvyWorkers.Processors.ScheduledEvents import (
    ScheduledEventManager, cast_scheduled_event_args
)
from DivvyWorkers.ScheduledWorkers.base import ScheduledEventJob
from worker.registry import Router


@ScheduledEventManager.register('action.set_container_lifecycle_configuration')
class SetContainerLifecycleConfiguration(ScheduledEventJob):

    def __init__(
        self, resource_id, user_resource_id, scheduled_event_id,
        scheduled_event_type, configuration
    ):
        super().__init__(
            resource_id=resource_id,
            user_resource_id=user_resource_id,
            scheduled_event_id=scheduled_event_id,
            scheduled_event_type=scheduled_event_type
        )
        self.configuration = configuration

    @SharedSessionScope(DivvyCloudGatewayORM)
    def run(self):
        # Form the frontend object using the organization service ID
        try:
            start_time = datetime.utcnow()
            frontend = get_cloud_type_by_organization_service_id(
                self.target_resource_id.organization_service_id
            )
            backend = frontend.get_cloud_gw()
            client = boto3.client(
                's3',
                aws_access_key_id=backend.auth_api_key,
                aws_secret_access_key=backend.auth_secret,
                aws_session_token=backend.session_token,
                region_name=self.target_resource_id.region
            )

            client.put_bucket_lifecycle_configuration(
                Bucket=self.target_resource_id.name,
                LifecycleConfiguration=json.loads(self.configuration)
            )
            result_data = None
        except Exception:
            result_data = traceback.format_exc()

        self.store_event_history(
            start_time=start_time,
            finish_time=datetime.utcnow(),
            status='ERROR' if result_data else 'SUCCESS',
            result_data=result_data
        )

def load():
    # Register the job
    Router.add_scheduled_event_job(
        'action.set_container_lifecycle_configuration',
        SetContainerLifecycleConfiguration,
        cast_scheduled_event_args
    )
