import json

from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyBotfactory.scheduling import ScheduledEventTracker, schedule_hours_from_now
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import FieldOptions, TextField, FloatField

registry = BotFactoryRegistryWrapper()


@registry.action(
    uid='custom.action.set_storage_container_lifecycle',
    name='Set Storage Container Lifecycle Configuration',
    bulk_action=True,
    description=(
        'Replaces the lifecycle configuraiton for an AWS storage container'
    ),
    author='DivvyCloud',
    supported_resources=[ResourceType.STORAGE_CONTAINER],
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    settings_config=[
        TextField(
            name='configuration',
            display_name='Lifecycle Configuration',
            options=FieldOptions.REQUIRED,
            description=(
                'The entire lifecycle configuration to apply. Note that this '
                'will replace any existing lifecycle configuration. For '
                'information please see '
                'https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html#S3.Client.put_bucket_lifecycle_configuration.'
            )
        ),
        FloatField(
            name='hours',
            display_name='Delay Hours',
            description=(
                'How many hours to wait before running event? Zero hours means '
                'the event will be scheduled for one minute out. Decimal '
                'values can be used to specify minutes. For example, to '
                'specify 15 minutes use 0.25.'
            ),
            min_value=0,
            preselected_values=0
        )
    ]
)
def create_vpc_flow_log_s3(bot, settings, matches, _non_matches):
    with ScheduledEventTracker() as cxt:
        # Build action data
        action_data = {'configuration': settings['configuration']}
        for resource in matches:
            cxt.schedule_bot_event(
                bot,
                resource,
                'Event Scheduled by bot.',
                'action.set_container_lifecycle_configuration',
                schedule_hours_from_now(settings.get('hours', 0)),
                action_data=json.dumps(action_data)
            )


def load():
    registry.load()
