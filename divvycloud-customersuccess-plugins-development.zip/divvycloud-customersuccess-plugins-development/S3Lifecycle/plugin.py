"""
Main plugin module for custom actions
"""
from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    """
    Information about this plugin
    """
    version = '1.0'
    last_updated_date = '2021-01-06'
    author = 'DivvyCloud'
    nickname = 'S3 Lifecycle Actions'
    default_language_description = 'Includes BotFactory actions for manipulating S3 lifecycle configurations'
    category = 'Actions'
    managed = False


def load():
    pass


def unload():
    pass
