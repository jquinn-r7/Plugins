
from DivvyPlugins.plugin_jobs import PluginJob
from worker.registry import Router

import csv
import json
import logging

from jinja2 import Template
from jira import JIRA

from datetime import datetime
from DivvyBotfactory.event import BotEvent
from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyUtils import misc
from DivvyUtils.field_definition import (
    FieldOptions, BooleanField, StringField, Jinja2StringField, Jinja2TextField,
    TextField
)
from DivvyBotfactory.scheduling import get_noncompliant_resource_ids

logger = logging.getLogger('Jira Integration (With Component)')
registry = BotFactoryRegistryWrapper()

@SharedSessionScope(DivvyCloudGatewayORM)
def get_jira_settings(organization_id):
    """
    Obtain the API and key values for the resource's organization
    """
    db = DivvyCloudGatewayORM()
    organization = db.session.query(DivvyDbObjects.Organization).get(organization_id)
    if not organization:
        raise ValueError("Unable to find organization")
    resource = organization.get_resource()

    # Get the API information for the payload
    username = resource.get_setting('divvy.jira.username')
    password = resource.get_setting('divvy.jira.password')
    server = resource.get_setting('divvy.jira.server')

    return username, password, server

def test_jira_settings(resource):
    """
    Obtain the required Splunk connection settings via the resource's
    organization.
    """
    # Get the API information for the incident payload
    username = resource.get_setting('divvy.jira.username')
    password = resource.get_setting('divvy.jira.password')
    server = resource.get_setting('divvy.jira.server')

    try:
        JIRA(
            basic_auth=(username.get_typed_value(), password.get_typed_value()),
            options={'server': server.get_typed_value()},
            max_retries=0
        )
    except Exception:
        raise Warning(
            'Unable to communicate with the JIRA instance. Please validate '
            'credentials and connectivity to the server'
        )

def add_list_param(param_name, param_string, issue_dict, list_item_tag = 'name'):
    """
     Add a 'list' style parameter to the Jira ticket
     param_name : the name of the parameter (Ex: "components")
     param_string : comma separated list of one or more item values (Ex: "Security,Product enhancement")
     issue_dict : the dictionary of params/values for the Jira ticket
     list_item_tag : the "key" for the items in the list, defaults to 'name'
     """
    param_array = []
    param_list = param_string.split(",")
    for param_item in param_list:
        c = {}
        c[list_item_tag] = param_item.strip()
        param_array.append(c)

    issue_dict.update({
        param_name: param_array
    })
    return issue_dict


@registry.action(
    uid='jira.action.create_task_with_component',
    name='Create/Update Jira Issue (With CSV attachment) (With component)',
    bulk_action=True,
    admin_only=True,
    description=(
            'Create an issue in the Jira portal. This will create the issue using '
            'the supplied credentials in the Jira integration settings, and includes'
            ' an optional components list. Note that this action creates a single'
            ' ticket per Bot and attaches a CSV with all findings. This action is'
            ' recommended for Bots that produce a high volume of findings.'
    ),
    author='DivvyCloud',
    supported_resources=[],
    settings_config=[
        StringField(
            name='project',
            display_name='Project',
            options=FieldOptions.REQUIRED,
            description=(
                    'Name of the project you would like to create the task in.'
            )
        ),
        StringField(
            name='components',
            display_name='components',
            #options=FieldOptions.REQUIRED,
            description=(
                    '(Optional) Name(s) of the component(s) you would like to create the task in. (comma-separated)'
            )
        ),
        StringField(
            name='summary',
            display_name='Summary',
            options=FieldOptions.REQUIRED,
            description='Brief title summary of the new task.'
        ),
        TextField(
            name='description',
            display_name='Description',
            options=FieldOptions.REQUIRED,
            description='Details about the issue and task.'
        ),
        StringField(
            name='issue_type',
            display_name='IssueType',
            options=FieldOptions.REQUIRED,
            description='Type of issue (e.g. Bug, Task, etc).'
        ),
        BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                    'When enabled, this will skip notification of resources which '
                    'are already marked noncompliant by this bot.'
            )
        )
    ]
)
def create_jira_task(bot, settings, matches, _non_matches):
    # This will only run if matches exist. Avoid creation a ticket for
    # not matches and an empty matches.
    if not matches:
        return

    db = DivvyCloudGatewayORM()
    username, password, server = get_jira_settings(
        organization_id=bot.organization_id
    )
    skip_duplicates = settings.get('skip_duplicates', False)

    if not username or not password or not server:
        raise ValueError(
            'Jira integration is not configured for this organization'
        )

    jira = JIRA(
        basic_auth=(username.get_typed_value(), password.get_typed_value()),
        options={'server': server.get_typed_value()},
        max_retries=0
    )

    ticket_mapping_row = db.session.query(
        DivvyDbObjects.ResourceProperty.resource_id,
        DivvyDbObjects.ResourceProperty.value
    ).filter(
        DivvyDbObjects.ResourceProperty.name == 'jira.issue_info'
    ).filter(
        DivvyDbObjects.ResourceProperty.resource_id == str(bot.resource_id)
    ).first()

    if not ticket_mapping_row:
        # Create initial JIRA issue
        issue_dict = {
            'project': settings['project'],
            'summary': settings['summary'],
            'description': settings['description'],
            'issuetype': settings['issue_type']
        }

        #process the components (optional) input
        component_string = settings['components']
        if (len(component_string) != 0):
            issue_dict = add_list_param('components', component_string, issue_dict)

        ticket = jira.create_issue(issue_dict)
        issue_dict.update({
            'id': str(ticket),
            'status': ticket.fields.status.name,
            'create_time': str(datetime.utcnow()),
            'html_link': '{0}/browse/{1}'.format(
                server.get_typed_value(), ticket.key
            )
        })
        bot.set_property(
            'jira.issue_info', json.dumps(issue_dict), 'json'
        )

    else:
        ticket_mapping = json.loads(ticket_mapping_row.value)
        ticket = jira.issue(ticket_mapping['id'])

    filename = '/tmp/{0}-{1}.csv'.format(bot.name, datetime.utcnow().replace(
        microsecond=0, tzinfo=None
    ))

    # Perform a query to get the cloud account names. At scale this avoids
    # having to pull down a lot of extra data from the DB.
    cloud_accounts = {}
    for row in db.session.query(
            DivvyDbObjects.OrganizationService.organization_service_id,
            DivvyDbObjects.OrganizationService.name
    ):
        cloud_accounts[row.organization_service_id] = row.name

    # Build resource matches into a CSV that will be attached
    data = False

    #  From the stackoverflow article on how to write csv binary files in python3:
    #  https://stackoverflow.com/questions/5358322/csv-modules-writer-wont-let-me-write-binary-out
    with open(filename, 'w', newline='', encoding='utf8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([
            'Provider ID', 'Name', 'Region Name', 'Resource Type', 'Cloud Account'
        ])
        with NewSession(DivvyCloudGatewayORM):
            db = DivvyCloudGatewayORM()

            # Get a list of noncompliant resource IDs
            noncompliant_resource_ids = []
            if skip_duplicates:
                noncompliant_resource_ids = get_noncompliant_resource_ids(
                    db, bot.resource_id
                )

            resource_ids = [match.resource_id for match in matches]
            for chunk in misc.chunks(resource_ids, 1000):
                for row in db.session.query(
                        DivvyDbObjects.ResourceCommonData.resource_id,
                        DivvyDbObjects.ResourceCommonData.provider_id,
                        DivvyDbObjects.ResourceCommonData.name,
                        DivvyDbObjects.ResourceCommonData.region_name,
                        DivvyDbObjects.ResourceCommonData.resource_type,
                        DivvyDbObjects.ResourceCommonData.organization_service_id
                ).filter(
                    DivvyDbObjects.ResourceCommonData.resource_id.in_(chunk)
                ):
                    if skip_duplicates and str(row.resource_id) in noncompliant_resource_ids:
                        continue
                    data = True
                    writer.writerow([
                        row.provider_id,
                        row.name,
                        row.region_name,
                        row.resource_type,
                        cloud_accounts.get(row.organization_service_id)
                    ])

    # Only add the attachment to the ticket if we have matched resources
    if data:
        jira.add_attachment(issue=ticket, attachment=filename)

@registry.action(
    uid='jira.action.create_issue_with_component',
    name='Create Individual Jira Issue (With Component)',
    bulk_action=True,
    admin_only=True,
    description=(
            'Create a JIRA issue for each resource identified by the Bot, including a Component'
            ' in the Jira issue. Note that this can result in a high volume of tickets.'
    ),
    author='DivvyCloud',
    supported_resources=[],
    settings_config=[
        StringField(
            name='project',
            display_name='Project',
            options=FieldOptions.REQUIRED,
            description=(
                    'Name of the project you would like to create the issue in.'
            )
        ),
        StringField(
            name='components',
            display_name='components',
            #options=FieldOptions.REQUIRED,
            description=(
                    '(Optional) Name(s) of the component(s) you would like to create the task in. (comma-separated)'
            )
        ),
        Jinja2StringField(
            name='summary',
            display_name='Summary',
            options=FieldOptions.REQUIRED,
            description='Brief title summary of the new issue (Jinja supported).'
        ),
        Jinja2TextField(
            name='description',
            display_name='Description',
            options=FieldOptions.REQUIRED,
            description='Details about the issue(Jinja supported).'
        ),
        StringField(
            name='issue_type',
            display_name='IssueType',
            options=FieldOptions.REQUIRED,
            description='Type of issue (e.g. Bug, Task, etc).'
        ),
        BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                    'When enabled, this will skip notification of resources which '
                    'are already marked noncompliant by this bot.'
            )
        )
    ]
)
def create_jira_issue(bot, settings, matches, _non_matches):

    # This will only run if matches exist. Avoid creation a ticket for
    # not matches and an empty matches.
    if not matches:
        return

    db = DivvyCloudGatewayORM()

    # Get a list of noncompliant resource IDs
    skip_duplicates = settings.get('skip_duplicates', False)
    noncompliant_resource_ids = []
    if skip_duplicates:
        noncompliant_resource_ids = get_noncompliant_resource_ids(
            db, bot.resource_id
        )

    username, password, server = get_jira_settings(
        organization_id=bot.organization_id
    )

    if not username or not password or not server:
        raise ValueError(
            'Jira integration is not configured for this organization'
        )

    jira = JIRA(
        basic_auth=(username.get_typed_value(), password.get_typed_value()),
        options={'server': server.get_typed_value()},
        max_retries=0
    )

    for resource in matches:
        if skip_duplicates and str(resource.resource_id) in noncompliant_resource_ids:
            continue

        # Stubs event so templates are backwards compatible
        event = BotEvent(
            'hookpoint', resource, bot.bot_id, bot.name, bot.resource_id,
            bot.insight_id, bot.insight_name, bot.severity, bot.description
        )


        # Parse summary/description
        # Note - Template() is a call that processes Jinja2 tags in the text that's passed in.
        #   Calling this with a field that has no Jinja2 tags has no effect, so it's safe
        #   To call for either version of the summary (with or without Jinja)
        summary_raw = Template(settings['summary'])
        try:
            summary = summary_raw.render(event=event, resource=resource)
        except Exception as e:
            summary = "Unable to parse summary [{0}]".format(e)
            logger.exception(summary)

        # Note - Template() is a call that processes Jinja2 tags in the text that's passed in.
        #   Calling this with a field that has no Jinja2 tags has no effect, so it's safe
        #   To call for either version of the description (with or without Jinja)
        description_raw = Template(settings['description'])
        try:
            description = description_raw.render(event=event, resource=resource)
        except Exception as e:
            description = "Unable to parse description [{0}]".format(e)
            logger.exception(description)


        # Create initial JIRA issue
        issue_dict = {
            'project': settings['project'],
            'summary': summary,
            'description': description,
            'issuetype': settings['issue_type'],
        }

        #process the components (optional) input
        component_string = settings['components']
        if (len(component_string) != 0):
            issue_dict = add_list_param('components', component_string, issue_dict)

        ticket = jira.create_issue(issue_dict)
        issue_dict.update({
            'id': str(ticket),
            'status': ticket.fields.status.name,
            'create_time': str(datetime.utcnow()),
            'html_link': '{0}/browse/{1}'.format(
                server.get_typed_value(), ticket.key
            )
        })

        bot.set_property(
            'jira.issue_info', json.dumps(issue_dict), 'json'
        )



class JiraWithComponent(PluginJob):
    worker_name = 'JiraWithComponent'
def run(self):
    pass

def __repr__(self):
    return "JiraWithComponent()"


def register():
    args = {}
    Router.add_job(JiraWithComponent, args=args)


def unregister():
    pass


def load():
    registry.load()
