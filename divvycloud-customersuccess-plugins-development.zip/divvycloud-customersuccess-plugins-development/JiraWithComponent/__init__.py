from . import JiraWithComponent
processor_module_list = [JiraWithComponent]

def register_processors():
    for module in processor_module_list:
        module.register()

def unregister_processors():
    for module in processor_module_list:
        module.unregister()
