import boto3
import json
import logging
import os
import zipfile
from datetime import datetime
from sqlalchemy import and_
from botocore.exceptions import ClientError

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DbObjects.resources import StorageContainer
from DivvyDb.DbObjects.insights import InsightPack
from DivvyDb.DbObjects.insights.back_office_insight import BackOfficeInsight, BackOfficeInsightResource
from DivvyDb.DbObjects.insights.insight import Insight, CustomInsightResource
from DivvyDb.DbObjects import OrganizationService, ResourceCommonData, Organization
from DivvyDb.DivvyDb import NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyResource.resource_matrix import ResourceMatrix
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('ComplianceExporterS3')

# Storage container name for storage of export files is taken from environment variable
# Note: the name is the container (bucket) name only, not the full ARN
STORAGE_CONTAINER_NAME = os.environ.get('COMPLIANCE_EXPORTER_STORAGE_CONTAINER_NAME')

#If Divvycloud is running on AWS EC2 with Instance Profile support for write access to the
# target S3 Bucket, set this environment variable
INSTANCE_PROFILE_SUPPORT = os.environ.get('INSTANCE_PROFILE_SUPPORT')
# Modify this to include the names of your target Insight pack(s)
# Note the pack(s) here must be custom pack(s)
PACK_NAMES = ['your-pack-name-here']

# path to the temp/scratch drive on the container or host
TMP_DIR_PATH = '/tmp'


class ComplianceExporterS3(PluginJob):
    worker_name = 'ComplianceExporterS3'

    def get_insight_results(self, backoffice_insight_ids, custom_insight_ids):
        with NewSession(DivvyCloudGatewayORM) as session:
            for resource_cls in [
                BackOfficeInsightResource, CustomInsightResource
            ]:
                insight_cls = BackOfficeInsight
                if resource_cls == CustomInsightResource:
                    insight_cls = Insight

                query = session.query(
                    resource_cls.resource_type,
                    resource_cls.identified_at,
                    resource_cls.organization_service_id,
                    resource_cls.state,
                    resource_cls.last_modified,
                    ResourceCommonData.provider_id,
                    ResourceCommonData.resource_id,
                    ResourceCommonData.region_name,
                    ResourceCommonData.namespace_id,
                    ResourceCommonData.name,
                    ResourceCommonData.pending_delete,
                    insight_cls.insight_id,
                    insight_cls.name.label('insight_name'),
                    insight_cls.description.label('insight_description'),
                    OrganizationService.name.label('account'),
                    OrganizationService.account_id,
                    OrganizationService.cloud_type_id
                ).outerjoin(
                    ResourceCommonData, and_(
                        resource_cls.auto_id == ResourceCommonData.auto_id,
                        resource_cls.resource_type == ResourceCommonData.resource_type
                    )
                ).filter(
                    resource_cls.insight_id == insight_cls.insight_id
                ).filter(
                    resource_cls.organization_service_id == OrganizationService.organization_service_id
                ).filter(
                    resource_cls.state.in_([0])  # Just 0 for noncompliant, [0,1] for compliant and non compliant
                ).filter(
                    OrganizationService.organization_id == Organization.organization_id
                ).filter(
                    Organization.simulated.is_(False)
                )

                if insight_cls == BackOfficeInsight:
                    source = 'backoffice'
                    if backoffice_insight_ids is not None:
                        query = query.filter(insight_cls.insight_id.in_(
                            backoffice_insight_ids
                        ))
                elif insight_cls == Insight:
                    source = 'custom'
                    if custom_insight_ids is not None:
                        query = query.filter(insight_cls.insight_id.in_(
                            custom_insight_ids
                        ))

                logger.info('Processing %s records for %s Insight findings', query.count(), source)
                for row in query:
                    yield row

    def get_storage_container_from_db(self, name):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                StorageContainer.organization_service_id,
                StorageContainer.resource_id
            ).filter(
                StorageContainer.name == name
            ).first()

    def get_packs_from_db(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            for row in session.query(
                    InsightPack.name,
                    InsightPack.description,
                    InsightPack.backoffice,
                    InsightPack.custom
            ).filter(
                InsightPack.name.in_(PACK_NAMES)
            ):
                yield row

    # Local copy of UploadFileToStorageContainer, used for the INSTANCE_PROFILE use case
    def UploadFileToStorageContainer(self, bucket, key, payload):
        """
        Uploads file to S3 bucket
        """
        s3 = boto3.client('s3')
        # First get the bucket location. We will need to update our driver
        # with the region to perform a file upload. The only calls that you can
        # make without specifying the region are list_buckets and
        # get_bucket_location.
        bucket_region_name = s3.get_bucket_location(Bucket=bucket)['LocationConstraint']
        # AWS magic, they can return us-east-1, None or US for the
        # bucket location which imply us-east-1
        if not bucket_region_name or bucket_region_name == 'US':
            bucket_region_name = 'us-east-1'
        elif bucket_region_name == 'EU':
            bucket_region_name = 'eu-west-1'

        s3 = boto3.client('s3', region_name=bucket_region_name)
        try:
            s3.upload_fileobj(
                Fileobj=payload,
                Bucket=bucket,
                Key=key
            )
        except s3.exceptions.NoSuchBucket:
            raise ValueError('Bucket does not exist in the cloud')
        except ClientError as e:
            if e.response['Error']['Code'] == 'AccessDenied':
                raise ValueError('Invalid cloud permission: Requires "PutObject"')
            if e.response['Error']['Code'] == 'SignatureDoesNotMatch':
                raise ValueError('Invalid cloud credentials')
            raise e

    def execute_scan(self):
        if not STORAGE_CONTAINER_NAME:
            raise Warning(
                'Please supply the storage container name'
            )

        # Get optional packs for scoping
        backoffice_insight_ids = set()
        custom_insight_ids = set()
        if PACK_NAMES:
            for pack in self.get_packs_from_db():
                if(pack.backoffice is not None):
                    for insight_id in pack.backoffice:
                        backoffice_insight_ids.add(insight_id)
                if (pack.custom is not None):
                    for insight_id in pack.custom:
                        custom_insight_ids.add(insight_id)

        if not backoffice_insight_ids and not custom_insight_ids:
            raise ValueError('Supplied pack(s) appear empty')

        total_resources = 0
        filename = 'divvycloud-insights-' + datetime.utcnow().replace(microsecond=0).isoformat() + '.txt'
        zipfilename = filename.replace('.txt', '.zip')
        filename_path = TMP_DIR_PATH + '/%s' % filename
        zipfilename_path = TMP_DIR_PATH + '/%s' % zipfilename

        f = open(filename_path, "w")
        for row in self.get_insight_results(
                backoffice_insight_ids, custom_insight_ids
        ):
            if row.state == 0:
                state = 'NONCOMPLIANT'
            else:
                state = 'COMPLIANT'

            msg = ''  # Placeholder for future use as context-specific information in the message
            # Build messsage
            if (row.pending_delete == 0):  # don't send message for resources that are pending deletion
                message = {
                    'insight_id': str(row.insight_id),
                    'insight_name': row.insight_name,
                    'insight_description': row.insight_description,
                    'divvy_resource_type': row.resource_type,
                    'divvy_resource_id': row.resource_id,
                    'provider_resource_type': getattr(ResourceMatrix, row.cloud_type_id)().get(row.resource_type, ''),
                    'provider_id': row.provider_id,
                    'state': state,
                    'account_name': row.account,
                    'account_id': row.account_id,
                    'cloud_type_id': row.cloud_type_id,
                    'region_name': row.region_name,
                    'resource_name': row.name,
                    'arn': row.namespace_id,
                    'last_modified': str(row.last_modified),
                    #'event_time': str(datetime.utcnow().replace(microsecond=0)),
                    'message': msg
                }
                total_resources += 1
                f.write(json.dumps(message) + '\n')

        f.close()
        # now write the file to a zip archive and upload to S3
        with zipfile.ZipFile(zipfilename_path, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(filename_path, filename)
            z.close()
            # reopen the file as binary read, for writing to S3
            f = open(zipfilename_path, "rb")
            if INSTANCE_PROFILE_SUPPORT:
                self.UploadFileToStorageContainer(STORAGE_CONTAINER_NAME,
                                                  zipfilename, f)
            else:
                # Lookup the frontend for this container
                container = self.get_storage_container_from_db(
                    STORAGE_CONTAINER_NAME
                )
                if not container:
                    raise Warning(
                        'Unable to lookup the container for the supplied container name'
                    )

                frontend = get_cloud_type_by_organization_service_id(container.organization_service_id)
                backend = frontend.get_cloud_gw()
                backend.UploadFileToStorageContainer(STORAGE_CONTAINER_NAME,
                                                     zipfilename, f)
            f.close()

        # clean up temp files
        os.remove(filename_path)
        os.remove(zipfilename_path)
        return total_resources

    def run(self):
        try:
            logger.info('starting Compliance')
            total_resources = self.execute_scan()
            logger.info('Scan finished. %s resources processed', total_resources)
        except Exception:
            logger.exception('Error during scan')

    def __repr__(self):
        return "ComplianceExporterS3()"


def register():
    args = {}
    Router.add_job(ComplianceExporterS3, args=args)
    scheduler_client.add_calendar_job(
        job=ComplianceExporterS3.__name__,
        args=args,
        #schedule=schedule.Daily(schedule.TimeOfDay(hour=18, minute=25))
        schedule = schedule.Hourly(minute_of_hour=0)

    )


def unregister():
    pass


def load():
    pass
