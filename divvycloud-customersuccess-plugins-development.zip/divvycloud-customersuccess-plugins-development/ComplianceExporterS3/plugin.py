from . import register_processors
from DivvyPlugins.plugin_metadata import PluginMetadata

class metadata(PluginMetadata):
    """
    Information about this plugin
    """
    version = '1.0.0'
    last_updated_date = '2020-01-22'
    author = 'Divvy Cloud Corp.'
    nickname = 'Compliance Exporter S3'
    support_email = 'support@divvycloud.com'
    managed = False


def load():
    register_processors()
