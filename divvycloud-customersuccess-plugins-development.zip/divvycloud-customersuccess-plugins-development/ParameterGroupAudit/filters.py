from sqlalchemy import and_, or_

from DivvyDb.DbObjects import ResourceProperty
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource import ResourceType

default_filters_author = 'Fidelity'


@QueryRegistry.register(
    query_id='fidelity.filter.oracle_database_with_invalid_parameter_values',
    name='Oracle Database With Invalid Parameters',
    description=(
        'Identify AWS RDS Databases which are running an Oracle engine with a '
        'default parameter group or a custom parameter group which violates '
        'acceptable parameter use.'
    ),
    author=default_filters_author,
    supported_resources=[ResourceType.DATABASE_INSTANCE],
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV
    ],
    version='21.2'
)
def oracle_database_with_invalid_parameter_values(query, db_cls, settings_config):
    session = query.session

    # TODO: Fidelity will need to expand on this
    parameter_mapping= {
        'audit_trail': ['DB'],
        'audit_sys_operations': ['TRUE'],
        # 'sec_case_sensitive_logon': ['TRUE'],
        # 'db_securefile': [],
        # 'o7_dictionary_accessibility': [],
        # 'os_authent_prefix': [],
        # 'os_roles': [],
        # 'remote_listener': [],
        # 'remote_login_passwordfile': [],
        # 'remote_os_roles': [],
        # 'sec_return_server_release_banner': [],
        # 'utl_file_dir': [],
        # '_trace_files_public': [],
        # 'sec_max_failed_login_attempts': []
    }

    # ResourceProperty subquery
    subq = session.query(
        ResourceProperty.resource_id
    ).filter(
        ResourceProperty.resource_id.like('dbinstance:%')
    )

    # Build OR columns
    or_stmts = []
    for parameter, acceptable_values in parameter_mapping.items():
        or_stmts.append(or_(and_(
            ResourceProperty.name == 'divvy.db_option.{0}'.format(parameter),
            ResourceProperty.value.notin_(acceptable_values)
        )))

    invalid_resource_ids = []
    for row in subq.filter(or_(*or_stmts)):
        invalid_resource_ids.append(row.resource_id)

    return query.filter(
        db_cls.engine.like('%{0}%'.format('oracle')),
        or_(
            db_cls.parameter_groups.like('%{0}%'.format('default.')),
            db_cls.resource_id.in_(invalid_resource_ids)
        )
    )


def load():
    pass
