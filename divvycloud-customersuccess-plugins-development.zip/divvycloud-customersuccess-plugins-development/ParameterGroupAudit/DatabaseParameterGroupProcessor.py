import boto3
import json
import logging
from collections import defaultdict
from sqlalchemy import and_

from DivvyCloudProviders.Common.Frontend.frontend import (
    get_cloud_type_by_organization_service_id
)
from DivvyDb.DbObjects import (
    DatabaseInstance, OrganizationService, ResourceProperty
)
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('DatabaseParameterGroupProcessor')


class DatabaseParameterGroupProcessor(PluginJob):
    worker_name = 'DatabaseParameterGroupProcessor'

    def get_instances(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                DatabaseInstance.region_name,
                DatabaseInstance.name,
                DatabaseInstance.instance_id,
                DatabaseInstance.engine,
                DatabaseInstance.engine_version,
                DatabaseInstance.resource_id,
                DatabaseInstance.database_cluster_resource_id,
                DatabaseInstance.organization_service_id,
                DatabaseInstance.parameter_groups
            ).filter(
                OrganizationService.organization_service_id == DatabaseInstance.organization_service_id,
                OrganizationService.cloud_type_id.startswith('AWS'),
                OrganizationService.status.in_([0, 1]),
                DatabaseInstance.engine.like('oracle%')
            ).order_by(
                DatabaseInstance.organization_service_id
            )

    def set_property(self, resource_id, name, value):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.merge(ResourceProperty(
                resource_id=resource_id,
                name=name,
                value=value,
                type_hint='string'
            ))

    def process_instance(self, client, instance):
        org_svc_id = instance.organization_service_id
        for parameter_group in instance.parameter_groups:
            if (
                not self.parameter_group_options.get(org_svc_id) or
                parameter_group not in self.parameter_group_options.get(org_svc_id)
            ):

                # TODO: Figure out how to get the default values
                # for pg in client.describe_db_parameter_groups(
                #     DBParameterGroupName=parameter_group
                # )['DBParameterGroups']:
                #     for parameter in client.describe_engine_default_parameters(
                #         DBParameterGroupFamily=pg['DBParameterGroupFamily']
                #     )['EngineDefaults']['Parameters']:
                #         name = parameter['ParameterName']
                #         value = parameter.get('ParameterValue')
                #         self.default_family_parameters[parameter_group][name] = value

                paginator = client.get_paginator('describe_db_parameters')
                pages = paginator.paginate(DBParameterGroupName=parameter_group)
                for page in pages:
                    for parameter in page['Parameters']:
                        if not self.parameter_group_options.get(org_svc_id, {}).get(parameter_group):
                            self.parameter_group_options[org_svc_id][parameter_group] = {}

                        name = parameter['ParameterName']
                        value = parameter.get(
                            'ParameterValue',
                            self.parameter_group_options.get(instance.engine)
                        )
                        value_to_set = None
                        if name in self.property_mapping['oracle'] and parameter.get('IsModifiable'):
                            # print(parameter)
                            if (
                                'oracle' in instance.engine and
                                name in self.property_mapping['oracle'] and
                                name not in self.parameter_group_options[org_svc_id][parameter_group]
                            ):
                                value_to_set = value
                                self.parameter_group_options[org_svc_id][parameter_group][name] = value

                            elif (
                                'oracle' in instance.engine and
                                name in self.property_mapping['oracle'] and
                                name in self.parameter_group_options[org_svc_id][parameter_group]
                            ):
                                value_to_set = self.parameter_group_options[org_svc_id][parameter_group][name]

                            if name in self.property_mapping['oracle']:
                                self.set_property(
                                    resource_id=instance.resource_id,
                                    name='divvy.db_option.{0}'.format(name),
                                    value=value_to_set if value_to_set else ''
                                )


    def run(self):
        instances = self.get_instances()
        self.parameter_group_options = defaultdict(dict)
        self.default_family_parameters = defaultdict(dict)
        self.property_mapping = {
            'oracle': [
                'audit_trail', 'audit_sys_operations', 'db_securefile',
                'sec_case_sensitive_logon', 'o7_dictionary_accessibility',
                'os_authent_prefix', 'os_roles', 'remote_listener',
                'remote_login_passwordfile', 'remote_os_roles',
                'sec_return_server_release_banner', 'utl_file_dir',
                '_trace_files_public', 'sec_max_failed_login_attempts'
            ],
            'sql': []
        }
        for instance in instances:
            frontend = get_cloud_type_by_organization_service_id(
                instance.organization_service_id
            )
            try:
                backend = frontend.get_cloud_gw()
            except Exception:
                # Bad account, let's continue
                continue

            client = boto3.client(
                'rds',
                aws_access_key_id=backend.auth_api_key,
                aws_secret_access_key=backend.auth_secret,
                aws_session_token=backend.session_token,
                region_name=instance.region_name
            )

            # RDS Instances
            if not instance.database_cluster_resource_id:
                try:
                    self.process_instance(client, instance)
                except Exception:
                    logger.exception('Unable to process instance')

            # TODO: Clusters maybe?

    def __repr__(self):
        return "DatabaseParameterGroupProcessor()"


def register():
    args = {}
    Router.add_job(DatabaseParameterGroupProcessor, args=args)
    scheduler_client.add_periodic_job(DatabaseParameterGroupProcessor.__name__, args, 60 * 24)


def unregister():
    pass

def load():
    pass

