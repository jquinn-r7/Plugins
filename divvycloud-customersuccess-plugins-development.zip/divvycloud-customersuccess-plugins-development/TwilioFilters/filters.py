from fnmatch import fnmatch
from collections import defaultdict

from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    BooleanField, FieldOptions, MultiSelectionField
)


default_filters_author = 'Twilio'


@QueryRegistry.register(
    query_id='twilio.filter.resource_policy_principal_search',
    name='Resource Specific Policy Principal Search (Plugin)',
    description=(
        'Match resources whose direct policy either contains or is missing '
        'desired target principal statements. Note that this '
        'filter only inspects direct policies such as S3 policies or KMS '
        'policies and only searches for AWS resources by ARN. It does not '
        'inspect cloud managed policies or search for AWS services. This '
        'filter can be extended to inspect for specific policy actions.'
    ),
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[
        ResourceType.STORAGE_CONTAINER,
        ResourceType.ELASTICSEARCH_INSTANCE,
        ResourceType.SERVICE_ENCRYPTION_KEY,
        ResourceType.CONTAINER_REGISTRY,
        ResourceType.MESSAGE_QUEUE,
        ResourceType.NOTIFICATION_TOPIC,
        ResourceType.SERVICE_ROLE,
        ResourceType.SERVERLESS_FUNCTION,
        ResourceType.NETWORK_ENDPOINT
    ],
    settings_config=[
        MultiSelectionField(
            choices=[],
            name='principals',
            display_name='Target Principals',
            description=(
                'The target principal ARNs or search terms. If any of the '
                'supplied principal ARNs are identified, the resource will be '
                'matched. Wildcards (*) are supported. To search for '
                'principals matching all AWS accounts, use AWS:* as the input.'
            ),
            options=[FieldOptions.REQUIRED, FieldOptions.TAGS]
        ),
        MultiSelectionField(
            choices=[],
            name='actions',
            display_name='Cloud Policy Actions (Optional)',
            description=(
                'Enter one or more policy actions, e.g., ec2:*, and at least '
                'one will be matched.'
            ),
            options=[FieldOptions.TAGS]
        ),
        MultiSelectionField(
            choices=[],
            name='whitelisted_organizations',
            display_name='Whitelisted Organization IDs (Optional)',
            description=(
                'Enter one or more AWS Organization IDs (e.g. o-alf2ef34n0). '
                'These will be used for conditional exclusion.'
            ),
            options=[FieldOptions.TAGS]
        ),
        BooleanField(
            name='not_in',
            display_name='Not In',
            description=(
                'When enabled, resources missing one or more of the supplied '
                'target principals will be matched.'
            )
        )
    ],
    version='19.4'
)
def resource_policy_role_search(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    column = 'policy'
    whitelisted_orgs = settings_config.get('whitelisted_organizations', [])
    if db_cls.resource_type == ResourceType.SERVICE_ROLE:
        column = 'assume_role_policy'

    # Make actions case insensitive and break them out by resource type
    required_actions = defaultdict(list)
    for action in settings_config.get('actions', []):
        action = action.lower()
        if action.startswith('s3:') or action == '*':
            required_actions[ResourceType.STORAGE_CONTAINER].append(action)
        elif action.startswith('kms:') or action == '*':
            required_actions[ResourceType.SERVICE_ENCRYPTION_KEY].append(action)
        elif action.startswith('es:') or action == '*':
            required_actions[ResourceType.ELASTICSEARCH_INSTANCE].append(action)
        elif action.startswith('ecr:') or action == '*':
            required_actions[ResourceType.CONTAINER_REGISTRY].append(action)
        elif action.startswith('sqs:') or action == '*':
            required_actions[ResourceType.MESSAGE_QUEUE].append(action)
        elif action.startswith('sns:') or action == '*':
            required_actions[ResourceType.NOTIFICATION_TOPIC].append(action)
        elif action.startswith('lambda:') or action == '*':
            required_actions[ResourceType.SERVERLESS_FUNCTION].append(action)

        # All actions are possible for roles/endpoints
        required_actions[ResourceType.SERVICE_ROLE].append(action)
        required_actions[ResourceType.NETWORK_ENDPOINT].append(action)

    # Iterate over the policies
    ids = []
    for row in db.session.query(
        db_cls.id,
        getattr(db_cls, column).label('policy')
    ).filter(
        getattr(db_cls, column).isnot(None)
    ):
        # Build a mapping of roles and the permissions included. This is done
        # because access can be spread acrosss multiple statements and we need
        # to aggregate them together.
        principal_permissions_mapping = defaultdict(list)
        all_actions = None
        try:
            statements = row.policy.get('Statement', [])
        except Exception:
            continue
        for statement in statements:
            if statement.get('Effect') == 'Allow':
                principal = statement.get('Principal')
                stmt_actions = statement.get('Action')
                condition = statement.get('Condition')
                if isinstance(stmt_actions, str):
                    stmt_actions = [stmt_actions]

                # This should never happen, but AWS does not fully prevent it.
                # It's considered a bad statement and is skipped by AWS, so
                # we will do the same thing.
                if not stmt_actions:
                    continue

                # Skip evaluation when there is a conditional that applies to a
                # organization
                if whitelisted_orgs and condition:
                    # StringEquals method
                    principal_org = condition.get('StringEquals', {}).get(
                        'aws:PrincipalOrgID'
                    )
                    if principal_org and principal_org in whitelisted_orgs:
                        continue

                    # ForAnyValue:StringEquals method
                    principal_paths = condition.get('ForAnyValue:StringEquals', {}).get(
                        'aws:PrincipalOrgPaths'
                    )
                    if principal_paths:
                        if isinstance(principal_paths, str):
                            principal_paths = [principal_paths]

                        unknown_orgs = []
                        for path in principal_paths:
                            if path.startswith('o-') and path.split('/')[0] not in whitelisted_orgs:
                                unknown_orgs.append(path.split('/')[0])

                        if not unknown_orgs:
                            continue

                # Skip evaluation when there is a conditional that applies IP
                # address filtering
                if condition and (
                    condition.get('IpAddress') or condition.get('NotIpAddress')
                ):
                    continue

                # Convert to lowercase for case insensitive comparison
                actions = [stmt_action.lower() for stmt_action in stmt_actions]

                if principal and isinstance(principal, str):
                    if principal == '*':
                        principal_permissions_mapping['AWS:*'].extend(actions)
                    else:
                        principal_permissions_mapping[principal].extend(actions)
                elif principal and isinstance(principal, dict):
                    if isinstance(principal.get('AWS'), list):
                        for arn in principal['AWS']:
                            principal_permissions_mapping[arn].extend(actions)
                    elif isinstance(principal.get('AWS'), str):
                        if principal.get('AWS') == '*':
                            principal_permissions_mapping['AWS:*'].extend(actions)
                        else:
                            principal_permissions_mapping[principal['AWS']].extend(actions)

        for principal in settings_config['principals']:
            if principal == 'AWS:*' and principal_permissions_mapping.get('AWS:*'):
                if not required_actions:
                    ids.append(row.id)
                else:
                    # The principal needs to also have all required actions
                    all_actions = True
                    matched_actions = []
                    for action in required_actions[db_cls.resource_type]:
                        for permission in principal_permissions_mapping['AWS:*']:
                            if fnmatch(action, permission):
                                matched_actions.append(action)

                    if len(required_actions[db_cls.resource_type]) != len(matched_actions):
                        all_actions = False

                    if all_actions:
                        ids.append(row.id)

            elif '*' not in principal and principal in principal_permissions_mapping.keys():
                if not required_actions:
                    ids.append(row.id)
                else:
                    # The principal needs to also have all required actions
                    all_actions = True
                    matched_actions = []
                    for action in required_actions[db_cls.resource_type]:
                        for permission in principal_permissions_mapping[principal]:
                            if fnmatch(action, permission):
                                matched_actions.append(action)

                    if len(required_actions[db_cls.resource_type]) != len(matched_actions):
                        all_actions = False

                    if all_actions:
                        ids.append(row.id)

            elif '*' in principal:
                for p in principal_permissions_mapping:
                    if fnmatch(p, principal):
                        if not required_actions:
                            ids.append(row.id)
                        else:
                            # The principal needs to also have all required actions
                            all_actions = True
                            matched_actions = []
                            for action in required_actions[db_cls.resource_type]:
                                for permission in principal_permissions_mapping[p]:
                                    if fnmatch(action, permission):
                                        matched_actions.append(action)

                            if len(required_actions[db_cls.resource_type]) != len(matched_actions):
                                all_actions = False

                            if all_actions:
                                ids.append(row.id)

    if settings_config.get('not_in'):
        query = query.filter(db_cls.id.notin_(ids))
    elif not settings_config.get('not_in'):
        query = query.filter(db_cls.id.in_(ids))
    return query




def load():
    pass
