import csv
import jinja2
import json
import logging
import os
from datetime import date, datetime
from sqlalchemy import and_

from DivvyApp.app_constants import Constants
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils.mail import send_email
from worker.registry import Router
from scheduler import client

logger = logging.getLogger('RoleScanner')

TARGET_RESOURCES = ['harness-delegate-role']
TARGET_ACTIONS = [
    'UpdateAssumeRolePolicy', 'DetachRolePolicy', 'AttachRolePolicy',
    'DeleteRole', 'PutRolePolicy', 'CreatePolicyVersion', 'DeletePolicyVersion'
]
EMAIL_RECIPIENTS = ['adutta@ancestry.com']

class RoleScanner(PluginJob):
    worker_name = 'RoleScanner'

    def get_roles(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                DbObjects.Role.name,
                DbObjects.Role.assume_role_policy
            ).filter(
                DbObjects.Role.name.in_(TARGET_RESOURCES)
            ).all()

    def create_history_table(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.execute('''
                CREATE TABLE IF NOT EXISTS `AncestryRoleScans` (
                  `start_time` DATETIME NOT NULL,
                  `end_time` DATETIME NOT NULL,
                  `total_events` INT(4) UNSIGNED NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
            ''')

    def get_last_run(self):
        last_scan_time = None
        with NewSession(DivvyCloudGatewayORM) as session:
            result = session.execute('''
                SELECT start_time FROM AncestryRoleScans
                  ORDER BY start_time DESC LIMIT 1
            ''').first()
            if result:
                last_scan_time = result.start_time
        return last_scan_time

    def set_last_run(self, start_time, end_time, total_events):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.execute('''
                INSERT INTO AncestryRoleScans VALUES ('{0}', '{1}', {2})
            '''.format(start_time, end_time, total_events))

    def get_organization_id(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                DbObjects.Organization.organization_id
            ).filter(
                DbObjects.Organization.resource_id ==
                DbObjects.OrganizationSetting.resource_id
            ).filter(
                DbObjects.OrganizationSetting.name == 'divvy.email.host'
            ).first()

    def get_events(self):
        last_scan_time = self.get_last_run()
        with NewSession(DivvyCloudGatewayORM) as session:
            query = session.query(
                DbObjects.ServiceEventHistory.action,
                DbObjects.ServiceEventHistory.source_ip,
                DbObjects.ServiceEventHistory.user_arn,
                DbObjects.ServiceEventHistory.timestamp,
                DbObjects.ResourceCommonData.name,
                DbObjects.ServiceEventParams.request_params,
                DbObjects.OrganizationService.account_id,
                DbObjects.OrganizationService.name.label('account')
            ).join(
                DbObjects.ServiceEventHistoryResource,
                DbObjects.ServiceEventHistory.event_id ==
                DbObjects.ServiceEventHistoryResource.event_id
            ).join(
                DbObjects.ServiceEventParams,
                DbObjects.ServiceEventHistory.event_id ==
                DbObjects.ServiceEventParams.event_id
            ).join(
                DbObjects.OrganizationService,
                DbObjects.OrganizationService.organization_service_id ==
                DbObjects.ServiceEventHistory.organization_service_id
            ).join(
                DbObjects.ResourceCommonData, and_(
                    DbObjects.ResourceCommonData.provider_id == DbObjects.ServiceEventHistoryResource.provider_id,
                    DbObjects.ResourceCommonData.organization_service_id == DbObjects.OrganizationService.organization_service_id
                )
            ).filter(
                DbObjects.ServiceEventHistory.action.in_(TARGET_ACTIONS),
                DbObjects.ResourceCommonData.name.in_(TARGET_RESOURCES)
            )

            if last_scan_time:
                query = query.filter(
                    DbObjects.ServiceEventHistory.timestamp > last_scan_time
                )

            return query.all()

    def process_notification(self, noncompliant_events, organization_id):
        dir_name = os.path.abspath(os.path.dirname(__file__))
        html_template_path = os.path.join(
            dir_name + '/templates/report.html'
        )

        csv_filename = '/tmp/role-report-{0}.csv'.format(
            datetime.utcnow().replace(microsecond=0, tzinfo=None)
        )
        headers = [
            'Resource Name', 'Account', 'Account ID', 'Event', 'User ARN',
            'Time', 'IP Address', 'Payload'
        ]
        with open(csv_filename, 'w', newline='', encoding='utf8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(headers)

            # Mutate mapping for now
            table_data = []
            for event in noncompliant_events:
                table_data.append(event)
                writer.writerow([
                    event['name'],
                    event['account'],
                    event['account_id'],
                    event['action'],
                    event['user_arn'],
                    event['timestamp'],
                    event['source_ip'],
                    event['request_params']
                ])

        with open(html_template_path, 'r') as fp:
            email_template = fp.read()
            message_body = jinja2.Template(email_template)
            formatted_body = message_body.render(
                table_data=table_data,
                today=date.today().strftime('%B %d, %Y'),
                year=datetime.utcnow().year,
                main_logo=Constants.mapping['insight_pack_logo'],
                main_logo_alt=Constants.mapping['company_name'],
            )

            send_email(
                subject='Role Scanner Report For {0}'.format(
                    date.today().strftime('%B %d, %Y')
                ),
                message=None,
                from_email='noreply@divvycloud.com',
                recipient_list=EMAIL_RECIPIENTS,
                organization_id=organization_id,
                html_message=formatted_body,
                inline_css=True,
                files=[csv_filename]
            )


    def run(self):
        noncompliant_events = []
        self.create_history_table()
        start_time = datetime.utcnow()
        events = self.get_events()
        db_obj = self.get_organization_id()
        if not db_obj:
            raise Warning(
                'Please configure the Email settings for this Organization'
            )
        organization_id = db_obj.organization_id
        total_events = 0
        for event in events:
            total_events += 1
            noncompliant_events.append(event._asdict())

        if noncompliant_events:
            logger.info('Processing notification for %s events', total_events)
            self.process_notification(noncompliant_events, organization_id)
        else:
            logger.info('No events to process for the target resources')

        end_time = datetime.utcnow()
        self.set_last_run(start_time, end_time, total_events)

    def __repr__(self):
        return "RoleScanner()"


def register():
    Router.add_job(RoleScanner, args={})
    client.add_periodic_job(RoleScanner.__name__, args={}, interval=5)

def unregister():
    pass

def load():
    pass