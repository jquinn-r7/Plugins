import boto3
import json
import logging
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
from sqlalchemy import and_

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('DatabaseCloudwatchProcessor')


class DatabaseCloudwatchProcessor(PluginJob):
    worker_name = 'DatabaseCloudwatchProcessor'

    def get_instances(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                DbObjects.DatabaseInstance.region_name,
                DbObjects.DatabaseInstance.name,
                DbObjects.DatabaseInstance.instance_id,
                DbObjects.DatabaseInstance.resource_id,
                DbObjects.DatabaseInstance.organization_service_id,
            ).filter(
                DbObjects.OrganizationService.organization_service_id == DbObjects.DatabaseInstance.organization_service_id,
                DbObjects.OrganizationService.cloud_type_id.startswith('AWS'),
                DbObjects.OrganizationService.status.in_([0, 1])
            ).all()

    def set_property(self, resource_id, name, value):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.merge(DbObjects.ResourceProperty(
                resource_id=resource_id,
                name=name,
                value=value,
                type_hint='float'
            ))

    def run(self):
        instances = self.get_instances()
        count = 0
        for instance in instances:
            count += 1
            msg = 'Getting metrics for RDS Instance {0} ({1}/{2})'.format(
                instance.instance_id, count, len(instances)
            )
            logger.info(msg)
            frontend = get_cloud_type_by_organization_service_id(
                instance.organization_service_id
            )
            try:
                backend = frontend.get_cloud_gw()
            except Exception:
                # Bad account, let's continue
                continue

            client = boto3.client(
                'cloudwatch',
                aws_access_key_id=backend.auth_api_key,
                aws_secret_access_key=backend.auth_secret,
                aws_session_token=backend.session_token,
                region_name=instance.region_name
            )

            metrics = {
                'CPUUtilization': 'Percent',
                'DatabaseConnections': 'Count',
                'FreeStorageSpace': 'Bytes'
            }

            for days in [14, 30, 60, 90, 180]:
                for stat in ['Average', 'Maximum']:
                    for metric, unit in metrics.items():
                        try:
                            response = client.get_metric_data(
                                MetricDataQueries=[
                                    {
                                        'Id': 'divvycloud',
                                        'MetricStat': {
                                            'Metric': {
                                                'Namespace': 'AWS/RDS',
                                                'MetricName': metric,
                                                'Dimensions': [
                                                    {
                                                        'Name': 'DBInstanceIdentifier',
                                                        'Value': instance.instance_id
                                                    },
                                                ]
                                            },
                                            'Period': 86400,
                                            'Stat': stat,
                                            'Unit': unit
                                        }
                                    },
                                ],
                                StartTime=datetime.utcnow() - timedelta(days=days),
                                EndTime=datetime.utcnow()
                            )
                        except ClientError:
                            # Likely hit by a permissions error
                            logger.error('Unable to pull CloudWatch information for %s' .instance.instance_id)
                            continue

                        metric_value = 0
                        for result in response.get('MetricDataResults', []):
                            for value in result['Values']:
                                if stat == 'Average':
                                    metric_value += value
                                else:
                                    if value > metric_value:
                                        metric_value = value

                        if stat == 'Average':
                            metric_value = round(float(metric_value / days), 2)
                            property_name = 'avg_{0}_{1}'.format(metric.lower(), days)
                        else:
                            property_name = 'max_{0}_{1}'.format(metric.lower(), days)

                        print(instance.resource_id, property_name, metric_value)
                        self.set_property(
                            instance.resource_id, property_name, metric_value
                        )

    def __repr__(self):
        return "DatabaseCloudwatchProcessor()"


def register():
    args = {}
    Router.add_job(DatabaseCloudwatchProcessor, args=args)
    scheduler_client.add_periodic_job(DatabaseCloudwatchProcessor.__name__, args, 60 * 24)


def unregister():
    pass

def load():
    pass

