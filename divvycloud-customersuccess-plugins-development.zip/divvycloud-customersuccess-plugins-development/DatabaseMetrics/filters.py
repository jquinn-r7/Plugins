from sqlalchemy import cast, Float

from DivvyDb.DbObjects import ResourceProperty
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    FieldOptions, OperatorField, FloatField, Op, SelectionField
)
from DivvyUtils.misc import bool_evaluate


default_filters_author = 'DivvyCloud'


@QueryRegistry.register(
    query_id='custom.query.cloudwatch_database_metrics',
    name='Database Instance Metric Threshold',
    description=(
        'Identify compute intances by the average/max network in/network out.'
    ),
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES
    ],
    supported_resources=[
        ResourceType.DATABASE_INSTANCE,
    ],
    settings_config=[
        SelectionField(
            name='metric',
            display_name='Metric',
            description='Select the target metric',
            choices=[
                ('avg_cpuutilization', 'Average CPU Utilization'),
                ('avg_databaseconnections', 'Average Database Connections'),
                ('avg_freestoragespace', 'Average Free Storage Space (Bytes)'),
                ('max_cpuutilization', 'Max CPU Utilization'),
                ('max_databaseconnections', 'Max Database Connections'),
                ('max_freestoragespace', 'Max Free Storage Space (Bytes)'),
            ],
            options=[FieldOptions.REQUIRED]
        ),
        SelectionField(
            name='days',
            display_name='Days',
            choices=[
                ('14', '14 Days'),
                ('30', '30 Days'),
                ('60', '60 Days'),
                ('90', '90 Days'),
                ('180', '180 Days')
            ],
            options=[FieldOptions.REQUIRED]
        ),
        FloatField(
            name='threshold',
            display_name='Threshold',
            description='Enter the target threshold',
            options=[FieldOptions.REQUIRED]
        ),
        OperatorField(
            name='operator',
            display_name='Operator',
            description='Select the desired operator',
            choices=[Op.LTE, Op.EQ, Op.GTE],
            options=[FieldOptions.REQUIRED]
        )
    ],
    version='20.6'
)
def cloudwatch_database_metrics(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()

    property_name = '{0}_{1}'.format(
        settings_config['metric'],
        settings_config['days']
    )
    threshold = settings_config['threshold']
    op = settings_config['operator']
    resource_ids = [row.resource_id for row in db.session.query(
        ResourceProperty.resource_id
    ).filter(
        ResourceProperty.name == property_name,
        bool_evaluate(
            cast(ResourceProperty.value, Float), op, threshold
        )
    )]

    return query.filter(db_cls.resource_id.in_(resource_ids))


def load():
    pass
