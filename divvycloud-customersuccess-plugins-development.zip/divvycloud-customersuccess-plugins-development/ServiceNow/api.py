import logging
from collections import defaultdict
from dateutil import parser
from flask import request

from DivvyBlueprints.v2 import Blueprint
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyPlugins.plugin_helpers import (
    register_api_blueprint, unregister_api_blueprints
)
from DivvyResource.Resources.base import get_db_class_for_type
from DivvySession import DivvySession
from DivvyUtils.flask_helpers import JsonResponse

blueprint = Blueprint('divvysnow', __name__)
logger = logging.getLogger('SNOW API')

@blueprint.route('/resources/<resource_type_str>', methods=['GET'])
def get_resource_information(resource_type_str):
    try:
        last_modified = parser.parse(request.args.get('last_modified'))
    except Exception:
        last_modified = None

    # Get session
    session = DivvySession.current_session()
    db = DivvyCloudGatewayORM()

    try:
        db_cls = get_db_class_for_type(resource_type_str)
    except KeyError:
        raise ValueError('Invalid/unknown resource type supplied')

    query = db.session.query(
        db_cls,
        DivvyDbObjects.ResourceCommonData.name,
        DivvyDbObjects.ResourceCommonData.provider_id,
        DivvyDbObjects.ResourceCommonData.region_name,
        DivvyDbObjects.OrganizationService.name.label('account'),
        DivvyDbObjects.OrganizationService.account_id,
        DivvyDbObjects.OrganizationService.cloud_type_id
    ).filter(
        db_cls.resource_id == DivvyDbObjects.ResourceCommonData.resource_id
    ).filter(
        DivvyDbObjects.ResourceCommonData.organization_service_id ==
        DivvyDbObjects.OrganizationService.organization_service_id
    ).filter(
        DivvyDbObjects.OrganizationService.status.in_([
            DivvyDbObjects.OrganizationService.Status.DEFAULT,
            DivvyDbObjects.OrganizationService.Status.REFRESH
        ])
    )

    if last_modified:
        query = query.filter(
            DivvyDbObjects.ResourceCommonData.modified_timestamp >= last_modified
        )

    tbl = db_cls.__table__
    dependency_columns = []
    for col in tbl.columns.keys():
        if '_resource_id' in col and col != 'instance_flavor_resource_id':
            dependency_columns.append(col)

    dependencies = []
    resource_ids = []
    resources = []
    for row in query:
        resource_dependency_ids = []
        resource_ids.append(row[0].resource_id)
        obj = {
            'resource_id': row[0].resource_id,
            'name': row.name,
            'provider_id': row.provider_id,
            'region_name': row.region_name if row.region_name else 'global',
            'account_id': row.account_id,
            'account': row.account,
            'cloud_type_id': row.cloud_type_id,
            'resource_type': resource_type_str,
            'dependencies': []
        }

        for column in dependency_columns:
            resource_id = getattr(row[0], column)
            if resource_id:
                resource_dependency_ids.append(resource_id)

        if resource_dependency_ids:
            for row in db.session.query(
                DivvyDbObjects.ResourceCommonData.resource_id,
                DivvyDbObjects.ResourceCommonData.name,
                DivvyDbObjects.ResourceCommonData.provider_id,
                DivvyDbObjects.ResourceCommonData.resource_type
            ).filter(
                DivvyDbObjects.ResourceCommonData.resource_id.in_(
                    resource_dependency_ids
                )
            ):
                obj['dependencies'].append({
                    'resource_id': row.resource_id,
                    'name': row.name,
                    'provider_id': row.provider_id,
                    'resource_type': row.resource_type
                })

        resources.append(obj)

    # Get dependencies
    dependencies = defaultdict(list)
    for row in db.session.query(
        DivvyDbObjects.ResourceLink.left_resource_id,
        DivvyDbObjects.ResourceLink.right_resource_id,
        DivvyDbObjects.ResourceCommonData.name,
        DivvyDbObjects.ResourceCommonData.provider_id,
        DivvyDbObjects.ResourceCommonData.resource_type
    ).join(
        DivvyDbObjects.ResourceCommonData,
        DivvyDbObjects.ResourceCommonData.resource_id ==
        DivvyDbObjects.ResourceLink.right_resource_id
    ).filter(
        DivvyDbObjects.ResourceLink.left_resource_id.in_(resource_ids)
    ):
        dependencies[row.left_resource_id].append({
            'resource_id': row.right_resource_id,
            'name': row.name,
            'provider_id': row.provider_id,
            'resource_type': row.resource_type
        })

    for resource in resources:
        resource['dependencies'].extend(
            dependencies.get(resource['resource_id'], [])
        )

    return JsonResponse(resources)


def load():
    register_api_blueprint(blueprint)

def unload():
    unregister_api_blueprints()
