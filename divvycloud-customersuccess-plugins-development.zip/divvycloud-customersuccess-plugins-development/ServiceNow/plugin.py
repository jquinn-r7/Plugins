from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    version = '1.0'
    last_updated_date = '2020-08-05'
    author = 'DivvyCloud Inc.'
    nickname = 'ServiceNow Export APIs'
    default_language_description = (
        'Custom API endpoints to enable data export for the SNOW team'
    )
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


def load():
    pass


def unload():
    pass
