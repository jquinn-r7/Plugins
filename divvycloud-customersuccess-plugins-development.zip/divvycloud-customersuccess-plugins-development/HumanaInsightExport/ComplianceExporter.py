import json
import logging
from datetime import datetime
from sqlalchemy import and_

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DbObjects.insights import BackOfficePack, InsightPack
from DivvyDb.DbObjects.insights.back_office_insight import BackOfficeInsight, BackOfficeInsightResource
from DivvyDb.DbObjects.insights.insight import Insight, CustomInsightResource
from DivvyDb.DbObjects import OrganizationService, ResourceCommonData, Organization
from DivvyDb.DbObjects.application import ResourceTag
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyPlugins.hookpoints import hookpoint
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyResource import ResourceIds
from DivvyResource.resource_matrix import ResourceMatrix
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('ComplianceExporter')

# Modify this to include the target Insight pack(s) to create OpsCenter items for
PACK_NAMES = ['CSP - Splunk Reporting']

# Update this to the target Google account ID where the storage bucket lives
TARGET_ACCOUNT_ID = 'global-eip-divvy-prd-1382'

# Define the storage bucket where you want the JSON output pushed to
# is edited or changed.
GOOGLE_STORAGE_BUCKET = 'divvy-snow-integration-prd'

# Severity mapping
SEVERITY_MAPPING = {
    1: 'Minor',
    2: 'Moderate',
    3: 'Major',
    4: 'Severe',
    5: 'Critical'
}

@hookpoint('divvycloud.resource.destroyed')
def resource_destroyed(resource, user_resource_id=None):
    """
    Update our history table to track the resource deletion
    """
    with NewSession(DivvyCloudGatewayORM) as session:
        session.execute('''
            REPLACE INTO ComplianceExporterResourceDeletion
              VALUES ("{0}", {1}, "{2}");
        '''.format(
            str(resource.resource_id),
            resource.organization_service_id,
            datetime.utcnow().replace(microsecond=0, tzinfo=None)
        ))


class ComplianceExporter(PluginJob):
    worker_name = 'ComplianceExporter'

    def create_history_table(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.execute('''
                CREATE TABLE IF NOT EXISTS `ComplianceExporterScans` (
                  `start_time` DATETIME NOT NULL,
                  `end_time` DATETIME NOT NULL,
                  `total_resources` INT(4) UNSIGNED NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
            ''')

            session.execute('''
                CREATE TABLE IF NOT EXISTS `ComplianceExporterResourceDeletion` (
                  `resource_id` varchar(255) NOT NULL,
                  `organization_service_id` int(4) NOT NULL,
                  `event_time` timestamp NOT NULL,
                  PRIMARY KEY (`resource_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
            ''')

    def populate_history_table(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            query = 'SELECT count(*) AS count FROM ComplianceExporterResourceDeletion;'
            insert_resource_history = True
            for row in session.execute(query):
                if row['count']:
                    insert_resource_history = False

            if insert_resource_history:
                query = '''
                INSERT INTO ComplianceExporterResourceDeletion
                  SELECT resource_id, organization_service_id, event_time
                  FROM ResourceHistory WHERE event_type_id = 'terminated';
                '''
                session.execute(query)

                for row in session.execute('''
                    SELECT resource_id, organization_service_id, modified_timestamp
                      FROM ResourceCommonData WHERE pending_delete = 1;
                '''):
                    session.execute('''
                        REPLACE INTO ComplianceExporterResourceDeletion
                          VALUES ("{0}", {1}, "{2}");
                    '''.format(
                        row['resource_id'],
                        row['organization_service_id'],
                        row['modified_timestamp']
                    ))

    def get_last_run(self):
        last_scan_time = None
        with NewSession(DivvyCloudGatewayORM) as session:
            result = session.execute('''
                SELECT start_time FROM ComplianceExporterScans
                  ORDER BY start_time DESC LIMIT 1
            ''').first()
            if result:
                last_scan_time = result.start_time
        return last_scan_time

    def set_last_run(self, start_time, end_time, total_resources):
        with NewSession(DivvyCloudGatewayORM) as session:
            session.execute('''
                INSERT INTO ComplianceExporterScans VALUES ('{0}', '{1}', {2})
            '''.format(start_time, end_time, total_resources))

    def get_insight_results(
        self, backoffice_insight_ids, custom_insight_ids, last_scan_time=None
    ):
        # Identify the last run date. If no run exists, then default to the
        # beginning of the calendar year.
        if not last_scan_time:
            last_scan_time = '2020-01-01 00:00:00'

        with NewSession(DivvyCloudGatewayORM) as session:
            for resource_cls in [
                BackOfficeInsightResource, CustomInsightResource
            ]:
                insight_cls = BackOfficeInsight
                if resource_cls == CustomInsightResource:
                    insight_cls = Insight
                    if not custom_insight_ids:
                        continue
                else:
                    insight_cls = BackOfficeInsight
                    if not backoffice_insight_ids:
                        continue

                query = session.query(
                    resource_cls.resource_type,
                    resource_cls.identified_at,
                    resource_cls.organization_service_id,
                    resource_cls.state,
                    resource_cls.last_modified,
                    ResourceCommonData.provider_id,
                    ResourceCommonData.resource_id,
                    ResourceCommonData.region_name,
                    ResourceCommonData.namespace_id,
                    ResourceCommonData.name,
                    insight_cls.insight_id,
                    insight_cls.name.label('insight_name'),
                    insight_cls.description.label('insight_description'),
                    insight_cls.severity,
                    OrganizationService.name.label('account'),
                    OrganizationService.account_id,
                    OrganizationService.cloud_type_id,
                    ResourceTag.tags
                ).join(
                    ResourceCommonData, and_(
                        resource_cls.auto_id == ResourceCommonData.auto_id,
                        resource_cls.resource_type == ResourceCommonData.resource_type
                    )
                ).outerjoin(
                    ResourceTag,
                    ResourceTag.resource_id == ResourceCommonData.resource_id
                ).filter(
                    resource_cls.insight_id == insight_cls.insight_id
                ).filter(
                    resource_cls.organization_service_id == OrganizationService.organization_service_id
                ).filter(
                    resource_cls.last_modified > last_scan_time
                ).filter(
                    resource_cls.state.in_([0, 1, 2])
                ).filter(
                    OrganizationService.organization_id == Organization.organization_id
                ).filter(
                    Organization.simulated.is_(False)
                )

                if insight_cls == BackOfficeInsight:
                    source = 'backoffice'
                    query = query.filter(insight_cls.insight_id.in_(
                        backoffice_insight_ids
                    ))
                elif insight_cls == Insight:
                    source = 'custom'
                    query = query.filter(insight_cls.insight_id.in_(
                        custom_insight_ids
                    ))

                logger.info('Processing %s records for %s Insight findings', query.count(), source)

                for row in query:
                    yield (row, source)

    def get_account_from_db(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                OrganizationService.organization_service_id,
            ).filter(
                OrganizationService.account_id == TARGET_ACCOUNT_ID
            ).first()

    def get_packs_from_db(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            for row in session.query(
                InsightPack.name,
                InsightPack.description,
                InsightPack.backoffice,
                InsightPack.custom
            ).filter(
                InsightPack.name.in_(PACK_NAMES)
            ):
                yield row

    def execute_scan(self):
        packs = [pack for pack in self.get_packs_from_db()]
        if not packs:
            raise Warning('Unable to pull any packs for the supplied pack names')

        account = self.get_account_from_db()
        if not account:
            raise Warning(
                'Unable to identify the OrganizationService for the supplied ID'
            )

        # Build a distinct grouping of Insights
        backoffice_insight_ids = set()
        custom_insight_ids = set()
        for pack in packs:
            for insight_id in pack.backoffice:
                backoffice_insight_ids.add(insight_id)
            for insight_id in pack.custom:
                custom_insight_ids.add(insight_id)

        last_scan_time = self.get_last_run()
        total_resources = 0
        failed_resources = 0

        frontend = get_cloud_type_by_organization_service_id(
            account.organization_service_id
        )
        backend = frontend.get_cloud_gw()
        data = []
        for resource, source in self.get_insight_results(
            backoffice_insight_ids, custom_insight_ids, last_scan_time
        ):
            total_resources += 1
            obj = resource._asdict()
            obj['source'] = source
            data.append(obj)

        # Create data in temporary file
        prefix = 'divvycloud-findings'
        now = datetime.utcnow()
        file_name = '{0}-{1}-{2:02}-{3:02}-{4}.json'.format(
            prefix, now.year, now.month, now.day, now.hour
        )
        with open('/tmp/' + file_name, 'a') as f:
            json.dump(data, f, indent=2, default=str)

        client = backend.client('storage', 'v1')
        request = client.objects().insert(
            bucket=GOOGLE_STORAGE_BUCKET,
            media_body='/tmp/{0}'.format(file_name),
            media_mime_type='application/octet-stream',
            body={'uploadType': 'media', 'name': file_name}
        )
        response = request.execute()
        return total_resources

    def run(self):
        self.create_history_table()
        self.populate_history_table()
        try:
            start_time = datetime.utcnow()
            total_resources = self.execute_scan()
        except Exception:
            logger.exception('Error during scan')
            total_resources = 0
        finally:
            end_time = datetime.utcnow()
            self.set_last_run(start_time, end_time, total_resources)

    def __repr__(self):
        return "ComplianceExporter()"


def register():
    args = {}
    Router.add_job(ComplianceExporter, args=args)
    scheduler_client.add_periodic_job(ComplianceExporter.__name__, args, 10)


def unregister():
    pass

def load():
    pass

