from . import register_processors, unregister_processors
from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    version = '2.0'
    last_updated_date = '2020-11-12'
    author = 'DivvyCloud Inc.'
    nickname = 'Humana Compliance Export'
    default_language_description = (
        'A plugin for Humana to feed Insight findings into Google Storage'
    )
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


def load():
    register_processors()

def unload():
    unregister_processors()
