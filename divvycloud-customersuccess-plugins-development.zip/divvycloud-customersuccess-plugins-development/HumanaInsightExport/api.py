from collections import defaultdict
from dateutil import parser
from flask import request

from DivvyBlueprints.v2 import Blueprint
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyPlugins.plugin_helpers import (
    register_api_blueprint, unregister_api_blueprints
)
from DivvyResource import ResourceIds
from DivvyUtils.flask_helpers import JsonResponse

blueprint = Blueprint('divvysnow', __name__)


@blueprint.route('/history', methods=['GET'])
def get_resource_information():
    try:
        event_time = parser.parse(request.args.get('event_time'))
    except Exception:
        event_time = None

    detail = request.args.get('detail') == 'true'
    resource_type = request.args.get('resource_type')
    db = DivvyCloudGatewayORM()

    if detail:
        account_mapping = {}
        resource_type_matrix = defaultdict(dict)
        for row in db.session.query(
            DivvyDbObjects.OrganizationService.organization_service_id,
            DivvyDbObjects.OrganizationService.name,
            DivvyDbObjects.OrganizationService.account_id,
            DivvyDbObjects.OrganizationService.cloud_type_id
        ):
            account_mapping[row.organization_service_id] = {
                'name': row.name,
                'account_id': row.account_id,
                'cloud_type_id': row.cloud_type_id
            }

        for row in db.session.query(
            DivvyDbObjects.ResourceMatrix
        ):
            resource_type_matrix[row.cloud_type_id][row.resource_type] = row.name

    where = ''
    if event_time and not resource_type:
        where += ' WHERE event_time > "{0}"'.format(event_time)

    elif not event_time and resource_type:
        where += ' WHERE resource_id LIKE "{0}:%"'.format(resource_type)

    elif event_time and resource_type:
        where += ' WHERE resource_id LIKE "{0}:%" AND event_time > "{1}"'.format(
            resource_type, event_time
        )

    query = 'SELECT * FROM ComplianceExporterResourceDeletion {0} ORDER BY 3;'.format(where)
    resources = []
    for row in db.session.execute(query):
        obj = {'resource_id': row.resource_id}
        if detail:
            try:
                resource_id = ResourceIds.ResourceId.from_string(row.resource_id)
                obj['organization_service_id'] = row.organization_service_id,
                obj['resource_type'] = resource_id.get_type(),
                obj['provider_id'] = resource_id.get_id(),
                obj['event_time'] = row.event_time

                account = account_mapping.get(row.organization_service_id)
                if account:
                    obj['account'] = account['name'],
                    obj['cloud_type_id'] = account['cloud_type_id'],
                    obj['account_id'] = account['account_id'],
                    obj['provider_resource_type'] = resource_type_matrix[account['cloud_type_id']].get(resource_id.get_type(), 'unknown')
            except Exception:
                pass

        resources.append(obj)

    return JsonResponse(resources)


def load():
    register_api_blueprint(blueprint)

def unload():
    unregister_api_blueprints()
