import json
import logging
from datetime import datetime

from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import NewSession
from DivvyInterfaceMessages import ResourceConverters
from DivvyPlugins.plugin_metadata import PluginMetadata
from DivvyPlugins.hookpoints import hookpoint

logger = logging.getLogger('ResourceDeletionInformation')

class metadata(PluginMetadata):
    version = '1.0'
    last_updated_date = '2020-11-12'
    author = 'DivvyCloud'
    nickname = 'Resource Deletion Storage'
    default_language_description = (
        'A plugin for long term storage of information about deleted cloud resources'

    )
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


@hookpoint('divvycloud.resource.destroyed')
def resource_destroyed(resource, user_resource_id=None):
    """
    Update our history table to track the resource deletion
    """
    try:
        with NewSession(DivvyCloudGatewayORM) as session:
            session.execute('''
                REPLACE INTO ResourceDeletionInformation
                  VALUES ('{0}', {1}, '{2}', '{3}');
            '''.format(
                str(resource.resource_id),
                resource.organization_service_id,
                datetime.utcnow().replace(microsecond=0, tzinfo=None),
                resource.get_resource().serialize()
            ))
    except Exception:
        logger.exception('Unable to add to ResourceDeletionInformation')

def create_history_table():
    with NewSession(DivvyCloudGatewayORM) as session:
        session.execute('''
            CREATE TABLE IF NOT EXISTS `ResourceDeletionInformation` (
              `resource_id` varchar(255) NOT NULL,
              `organization_service_id` int(4) NOT NULL,
              `event_time` timestamp NOT NULL,
              `resource` json DEFAULT NULL,
              PRIMARY KEY (`resource_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        ''')

def load():
    create_history_table()
