from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    """
    Information about email sending plugin.
    """
    version = '1.1'
    last_updated_date = '2020-10-08'
    author = 'DivvyCloud Inc.'
    nickname = 'KBS Tag Filters'
    default_language_description = 'Filters for tag compliance'
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


def load():
    pass


def unload():
    pass
