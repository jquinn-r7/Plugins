from fnmatch import fnmatch
from collections import defaultdict
from sqlalchemy import and_, not_, or_, func

from DivvyDb import DivvyDbObjects as dbo
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyDb.QueryFilters.tag import RESOURCES_SUPPORTING_TAGS
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    BooleanField, FieldOptions, MultiSelectionField
)


default_filters_author = 'KBS'

REQUIRED_TAGS = {
    'blc': ['1460'],
    'costcenter': [],
    'itemid': [],
    'description': [],
    'segment': [],
    'org': [],
    'owner': [],
    'dr': ['1', '2', '3'],
    'dataclassification': ['Highly Confidential', 'Confidential', 'General', 'Public']
}

REQUIRED_FALLBACK_TAGS = ['owneralternate', 'ticketgroup']


@QueryRegistry.register(
    query_id='kbs.filter.kbs_tag_policy_standard',
    name='GP Tagging Standard Violations',
    description=(
        'Match resources which are in violation of the GP tagging standard'
    ),
    supported_resources=RESOURCES_SUPPORTING_TAGS,
    supports_common=True,
    settings_config=[
        MultiSelectionField(
            choices=[],
            name='additional_tags',
            display_name='Additional Tags (Optional)',
            description=(
                'Enter one or more tag keys to include (e.g. Name). Note that '
                'these are case sensitive'
            ),
            options=[FieldOptions.TAGS]
        )
    ],
    version='20.3'
)
def kbs_tag_policy_standard(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    required_args = ()
    for key in REQUIRED_TAGS:
        required_args = required_args + ('$."' + key + '"',)

    args = ()
    for key in REQUIRED_FALLBACK_TAGS:
        args = args + ('$."' + key + '"',)

    clauses = or_(
        not_(func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'all', *required_args)),
        not_(func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'one', *args)),
        not_(
            and_(
                func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'one', '$."dataclassification"'),
                func.LOWER(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                    dbo.ResourceTag.tags, '$."dataclassification"'
                ))).in_(['highly confidential', 'confidential', 'general', 'public'])
            )
        ),
        not_(
            func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."dr"'
            )).in_(['1', '2', '3'])
        ),
        not_(
            func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."blc"'
            )).in_(['1460'])
        ),
        not_(
            func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."costcenter"'
            ))) == 10
        ),
        not_(
            func.LOWER(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."org"'
            ))).in_(
                db.session.query(dbo.CollectionData.value)
            )
        ),
        not_(
            func.LOWER(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."segment"'
            ))).in_(
                db.session.query(dbo.CollectionData.value)
            )
        ),
        not_(
            func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."description"'
            ))) > 2
        ),
        not_(
            func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."itemid"'
            ))) > 2
        )
    )

    for tag in settings_config.get('additional_tags', []):
        tag_key = '$."{0}"'.format(tag)
        next_clause = not_(
            and_(
                func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'one', tag_key),
                func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                    dbo.ResourceTag.tags, tag_key
                ))) >= 1
            )
        )
        clauses = or_(clauses, next_clause)

    subq = db.session.query(dbo.ResourceTag.resource_id).filter(clauses)
    tags_subq = db.session.query(dbo.ResourceTag.resource_id)
    owner_email_subq = db.session.query(
        dbo.ResourceTag.resource_id
    ).filter(
        or_(
            func.JSON_EXTRACT(dbo.ResourceTag.tags, '$."owner"').notlike('%@%'),
            func.JSON_EXTRACT(dbo.ResourceTag.tags, '$."owneralternate"').notlike('%@%')
        )
    )

    return query.filter(or_(
        db_cls.resource_id.in_(subq),
        db_cls.resource_id.in_(owner_email_subq),
        db_cls.resource_id.notin_(tags_subq),
    ))


@QueryRegistry.register(
    query_id='kbs.filter.kbs_iam_policy_standard',
    name='GP IAM User/Role Tagging Standard Violations',
    description=(
        'Match resources which are in violation of the GP tagging standard '
        'for users and roles.'
    ),
    supported_resources=[
        ResourceType.SERVICE_USER,
        ResourceType.SERVICE_ROLE
    ],
    settings_config=[],
    version='20.4'
)
def kbs_iam_policy_standard(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    resource_ids = []
    subq = db.session.query(
        dbo.ResourceTag.resource_id,
        dbo.ResourceTag.tags
    ).filter(
        and_(
            func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'one', '$."owner"'),
            func.JSON_UNQUOTE(func.JSON_EXTRACT(
                dbo.ResourceTag.tags, '$."owner"'
            )).like('%@%')
        ),
        func.JSON_CONTAINS_PATH(dbo.ResourceTag.tags, 'one', '$."type"'),
        func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
            dbo.ResourceTag.tags, '$."description"'
        ))) > 2,
        func.JSON_UNQUOTE(func.JSON_EXTRACT(
            dbo.ResourceTag.tags, '$."type"'
        )).in_(['vendor', 'service', 'user'])
    ).filter(
        dbo.ResourceTag.resource_id.like('{0}:%'.format(db_cls.resource_type))
    )

    for row in subq:
        if row.tags['type'].lower() in ['vendor', 'service']:
            if 'owneralternate' in row.tags and row.tags['owneralternate']:
                resource_ids.append(row.resource_id)
            elif 'ticketgroup' in row.tags and row.tags['ticketgroup']:
                resource_ids.append(row.resource_id)
        elif row.tags['type'].lower() == 'user':
            resource_ids.append(row.resource_id)

    return query.filter(db_cls.resource_id.notin_(resource_ids))


def load():
    pass
