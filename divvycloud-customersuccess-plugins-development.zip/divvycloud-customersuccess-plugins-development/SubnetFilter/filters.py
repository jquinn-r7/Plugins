from sqlalchemy import or_

from DivvyDb import DivvyDbObjects as dbo
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    FieldOptions, MultiSelectionField, BooleanField
)


default_filters_author = 'DivvyCloud'


@QueryRegistry.register(
    query_id='custom.query.resource_in_subnet_by_name',
    name='Resource Is In Subnet By Name',
    description=(
        'Identify resources which are running in a particular subnet by name'
    ),
    supported_clouds=[],
    supported_resources=[
        ResourceType.AUTOSCALING_GROUP,
        ResourceType.DATABASE_INSTANCE,
        ResourceType.INSTANCE,
        ResourceType.LOAD_BALANCER,
        ResourceType.NETWORK_INTERFACE,
        ResourceType.RESOURCE_ACCESS_LIST,
        ResourceType.SERVERLESS_FUNCTION,
        ResourceType.SHARED_FILE_SYSTEM,
        ResourceType.STREAM_INSTANCE,
        ResourceType.WEB_APP
    ],
    settings_config=[
        MultiSelectionField(
            choices=[],
            name='subnet_name_list',
            display_name='Subnet Name List',
            description=(
                'Enter one or more subnet names. Note, if more than one subnet '
                'is provided, resources in any of the provided subnets will be '
                'matched.'
            ),
            options=[FieldOptions.REQUIRED, FieldOptions.TAGS]
        ),
        BooleanField(
            name='not_in',
            display_name='Not In',
            description=(
                'When enabled, resources not in the supplied subnet(s) will '
                'be matched.'
            )
        ),
        BooleanField(
            name='exact_match',
            display_name='Exact Match',
            description=(
                'When enabled, the names above must be an exact match. If not '
                'enabled then wildcard matching will be used.'
            )
        )
    ],
    version='21.2'
)
def resource_in_subnet_by_name(query, db_cls, settings_config):
    session = query.session
    subnet_resource_ids = []
    subnet_query = session.query(dbo.NetworkSubnet.resource_id)
    if settings_config.get('exact_match'):
        subnet_query = subnet_query.filter(
            dbo.NetworkSubnet.name.in_(settings_config['subnet_name_list'])
        )
    else:
        or_stmts = or_()
        for name in settings_config['subnet_name_list']:
            or_stmts.append(
                dbo.NetworkSubnet.name.like('%{0}%'.format(name))
            )
        subnet_query = subnet_query.filter(or_(*or_stmts))

    subnet_resource_ids = [row.resource_id for row in subnet_query]

    if db_cls.resource_type == ResourceType.INSTANCE:
        subq = session.query(
            dbo.NetworkInterface.instance_resource_id
        ).filter(
            dbo.NetworkInterface.subnet_resource_id.in_(subnet_resource_ids)
        ).filter(
            dbo.NetworkInterface.instance_resource_id.isnot(None)
        )

        if not settings_config.get('not_in'):
            query = query.filter(db_cls.resource_id.in_(subq))
        else:
            query = query.filter(db_cls.resource_id.notin_(subq))

    elif db_cls.resource_type in [
        ResourceType.NETWORK_INTERFACE, ResourceType.WEB_APP
    ]:
        # Webapps can have secondary/tertiary subnets which are stored as links
        resource_link_subq = session.query(
            dbo.ResourceLink.left_resource_id
        ).filter(
            dbo.ResourceLink.right_resource_id.in_(subnet_resource_ids)
        )

        if not settings_config.get('not_in'):
            query = query.filter(or_(
                db_cls.subnet_resource_id.in_(subnet_resource_ids),
                db_cls.subnet_resource_id.in_(resource_link_subq),
            ))
        else:
            query = query.filter(and_(
                db_cls.subnet_resource_id.notin_(subnet_resource_ids),
                db_cls.subnet_resource_id.notin_(resource_link_subq),
            ))

    else:
        subq = session.query(
            dbo.ResourceLink.left_resource_id
        ).filter(
            dbo.ResourceLink.right_resource_id.in_(subnet_resource_ids)
        )

        if not settings_config.get('not_in'):
            query = query.filter(db_cls.resource_id.in_(subq))
        else:
            query = query.filter(db_cls.resource_id.notin_(subq))

    return query



def load():
    pass
