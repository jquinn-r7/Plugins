from sqlalchemy import or_, and_, func

from DivvyDb import DivvyDbObjects as dbo
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import BooleanField, FieldOptions, BadgeField, SelectionField

default_filters_author = 'DivvyCloud'

# These values match what is stored in the DB for the data_type field
# So, they can be used directly in queries
PLUGIN_STRING_TYPE_LIST = [
    'String',
    'SecureString',
    'StringList'
]

@QueryRegistry.register(
    query_id='custom.query.resource_stored_parameter_type',
    name='Parameter Store With Secure String Type',
    description=(
        'TODO add this'
    ),
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[
        ResourceType.STORED_PARAMETER,
    ],
    settings_config=[
        SelectionField(
            name='parameter_type',
            display_name='Parameter Type',
            options=FieldOptions.REQUIRED,
            choices=PLUGIN_STRING_TYPE_LIST,
            description='Type of parameter string.'
        ),
    ],
    version='21.1.2'
)

def resource_cross_account_account_by_badge(query, db_cls, settings_config):
    db = DivvyCloudGatewayORM()
    return query.filter(db_cls.data_type == settings_config['parameter_type'])


def load():
    pass
