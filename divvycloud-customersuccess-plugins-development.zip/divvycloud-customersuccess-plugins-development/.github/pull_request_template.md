## Description
<!-- Describe what this change does and why it is needed. -->
<!-- Add JIRA link if applicable -->

## Testing
<!-- Describe how this change was tested -->

<!-- For more information see: https://wiki.corp.rapid7.com/x/eSxMBg -->
