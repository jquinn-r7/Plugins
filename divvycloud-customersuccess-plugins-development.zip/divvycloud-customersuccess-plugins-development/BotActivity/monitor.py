import jinja2
import json
import os

from DivvyPlugins.hookpoints import hookpoint
from DivvyUtils.mail import send_email

EMAIL_RECIPIENTS = ['chris@divvycloud.com']

def bot_has_risky_event(bot):
    actions = {
        'divvy.action.create_db_instance_snapshot',
        'divvy.action.database_instance_stop_start_by_tag_value',
        'divvy.action.periodic_start',
        'divvy.action.periodic_start_db',
        'divvy.action.periodic_stop',
        'divvy.action.periodic_stop_db',
        'divvy.action.scheduled_deletion',
        'divvy.action.stop_start_by_tag_value',
        'divvy.action.suspend_resume_asg_by_tag_value',
        'divvy.action.ttl_deletion',
        'divvy.action.force_delete_instance',
        'divvy.start_db_cluster',
        'divvy.start_db_instance',
        'divvy.start_machine_learning_instance',
        'divvy.start_resource',
        'divvy.stop_db_cluster',
        'divvy.stop_db_instance',
        'divvy.stop_machine_learning_instance',
        'divvy.stop_resource',
        'divvy.delete_resource'
    }
    result = False
    for a in bot.instructions.actions:
        if a.uid in actions:
            result = True
            break
    return result


def send_notification(bot, action):
    dir_name = os.path.abspath(os.path.dirname(__file__))
    html_template_path = os.path.join(
        dir_name + '/templates/bot_report.html'
    )

    with open(html_template_path, 'r') as fp:
        email_template = fp.read()
        message_body = jinja2.Template(email_template)
        formatted_body = message_body.render(
            instructions=json.dumps(bot._asdict(), indent=2)
        )

        send_email(
            subject='Disruptive Bot {0}: {1}'.format(action, bot.name),
            message=None,
            from_email='noreply@divvycloud.com',
            recipient_list=EMAIL_RECIPIENTS,
            organization_id=bot.organization_id,
            html_message=formatted_body,
            inline_css=True
        )


@hookpoint('divvycloud.divvybot.created')
def bot_created(bot, user_resource_id=None, project_resource_id=None):
    risky_events = bot_has_risky_event(bot)
    if risky_events:
        send_notification(bot, action='Created')


# Uncomment for modification detection as well
# @hookpoint('divvycloud.divvybot.modified')
# def bot_modified(bot, user_resource_id=None, project_resource_id=None):
#     risky_events = bot_has_risky_event(bot)
#     if risky_events:
#         send_notification(bot, action='Modified')


def load():
    pass