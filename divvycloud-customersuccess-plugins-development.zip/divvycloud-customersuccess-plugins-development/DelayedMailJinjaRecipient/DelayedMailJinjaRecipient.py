
from DivvyPlugins.plugin_jobs import PluginJob
from worker.registry import Router

import json
import logging
import re
from jinja2 import Template
from sqlalchemy import func, or_
from datetime import datetime, timedelta
from DivvyBotfactory.event import BotEvent
from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope
from DivvyUtils import schedule, misc

from DivvyUtils.field_definition import (
    FieldOptions, BooleanField, StringField, Jinja2StringField, Jinja2TextField,
    MultiSelectionField, FloatField
)
from DivvyBotfactory.scheduling import get_noncompliant_resource_ids, ScheduledEventTracker

default_actions_author = 'DivvyCloud Inc.'
logger = logging.getLogger('Delayed Mail with Jinja Recipient')
registry = BotFactoryRegistryWrapper()


@SharedSessionScope(DivvyCloudGatewayORM)
def is_valid_email(email_str):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email_str)


def schedule_hours_from_now(hours):
    """Build schedule in UTC."""
    # If hours isn't set, schedule six seconds out for near realtime
    minutes = max(1, float(hours) * 60) if hours else 0.1
    delta = timedelta(minutes=minutes)
    return schedule.Once(when=datetime.utcnow() + delta)


def separate_emails(input_value, separator=';'):
    values = []
    if separator in input_value:
        values = input_value.split(separator)
    else:
        values = [input_value]
    return values


def extract_emails_from_tag_value(key, dictionary, tag_value, separator=';'):
    if key not in dictionary:
        dictionary[key] = []

    values = separate_emails(tag_value, separator)
    for value in values:
        if is_valid_email(value):
            dictionary[key].append(value)


def get_email_tags_for_resources(db, chunk, tag_keys, separator=';'):
    value_mapping = {}
    resource_ids = [
        str(resource.resource_id) for resource in chunk
    ]

    # Lowercase the tags
    col = func.lower(DivvyDbObjects.ResourceTag.tags)

    # Build subq or OR statements for each tag key
    clauses = or_()  # empty starting value
    for key in tag_keys:
        if '"' in key:
            key = key.replace('"', '\\"')
        next_clause = or_(
            func.JSON_CONTAINS_PATH(col, 'one', '$."' + key.lower() + '"')
        )
        clauses = or_(clauses, next_clause)

    query = db.session.query(
        DivvyDbObjects.ResourceTag.resource_id,
        DivvyDbObjects.ResourceTag.tags
    ).filter(
        DivvyDbObjects.ResourceTag.resource_id.in_(
            resource_ids
        )
    ).filter(clauses)

    for row in query:
        # Convert tags to lower.
        lc_tags = {k.lower(): v for k, v in row.tags.items()}
        for key in tag_keys:
            value = lc_tags.get(key.lower(), None)
            if value:
                extract_emails_from_tag_value(
                    row.resource_id, value_mapping, value, separator
                )

    return value_mapping


def get_email_badges_for_resources(db, chunk, badge_keys, separator=';'):
    badge_mapping = {}

    target_resource_ids = {
        'divvyorganizationservice:' + str(r.organization_service_id) for r in chunk
    }

    for row in db.session.query(
        DivvyDbObjects.Badge.organization_service_id,
        DivvyDbObjects.Badge.value,
    ).filter(
        DivvyDbObjects.Badge.target_resource_id.in_(
            target_resource_ids
        )
    ).filter(
        DivvyDbObjects.Badge.key.in_(
            badge_keys
        )
    ):
        extract_emails_from_tag_value(
            row.organization_service_id, badge_mapping, row.value, separator
        )

    return badge_mapping


@registry.action(
    uid='divvy.action.send_delayed_email_jinja_recipient',
    name='Send Delayed Email (with Jinja recipient)',
    description=(
        'Schedules a send email and allows email body, subject and recipient to '
        'be formatted with resource attributes using Jinja2 templates. For example,'
        ' use {{resource.name}} to include resource name. To include all resource '
        'details, use syntax {{resource.serialize(indent=2)}}'
    ),
    author=default_actions_author,
    bulk_action=True,
    supported_clouds=[],
    supported_resources=[],
    settings_config=[
        Jinja2StringField(
            name='message_subject',
            display_name='Email Subject Line',
            description=(
                    'Subject line of the message which should be sent. '
                    'Supports Jinja templating. New to Jinja2? Use this syntax to show all '
                    'resource details: {{resource.serialize(indent=2)}}'
            ),

            options=[FieldOptions.REQUIRED, FieldOptions.JINJA_PREVIEW]
        ),
        Jinja2TextField(
            name='message_body',
            display_name='Email Body',
            description=(
                'Contents of the message which should be sent. '
                'Supports Jinja templating.'
            ),
            options=[FieldOptions.REQUIRED, FieldOptions.JINJA_PREVIEW]
        ),
        MultiSelectionField(
            choices=[],
            options=[FieldOptions.TAGS_EMAIL],
            name='recipient_list',
            display_name='Message Recipient Emails',
            description='Who should receive the message?'
        ),
        Jinja2StringField(
            name='recipient_jinja',
            display_name='Recipient using Jinja (Optional)',
            description=(
                    'Attempt to dynamically assign the recipient via Jinja template. '
            ),
            options=[FieldOptions.JINJA_PREVIEW]
        ),
        MultiSelectionField(
            name='recipient_tag_keys',
            display_name='Recipient Tag Keys (Optional)',
            description=(
                'Attempt to dynamically assign the recipient via one or more '
                'tags. As an example you can use Owner which add the value of '
                'the tag key Owner if it exists on the resource. If the tag '
                'does not exist, then the system will only Email the '
                'individuals in the Emails above. Note the values are case '
                'insensitive.'
            ),
            choices=[],
            options=[FieldOptions.TAGS]
        ),
        MultiSelectionField(
            name='recipient_badge_keys',
            display_name='Recipient Badge Keys (Optional)',
            description=(
                'Attempt to dynamically assign the recipient via one or more '
                'badges. As an example you can use Owner which add the value of '
                'the badge key Owner if it exists on the resource. If the badge '
                'does not exist, then the system will only Email the '
                'individuals in the Emails above. Note the values are case '
                'sensitive.'
            ),
            choices=[],
            options=[FieldOptions.TAGS]
        ),
        StringField(
            name='separator',
            display_name='Email Separator (Optional)',
            description=(
                'The character(s) to use to split the dynamic values obtained '
                'from the recipient tag/badge/jinja fields above. If not set, this '
                'defaults to ;'
            )
        ),
        FloatField(
            name='hours',
            display_name='Delay Hours',
            description=(
                'How many hours to wait before sending the Email message? Zero '
                'hours means the event will be scheduled for one minute out. '
                'Decimal values can be used to specify minutes. For example, to '
                'specify 15 minutes use 0.25.'
            ),
            min_value=0,
            preselected_values=24,
            options=FieldOptions.REQUIRED
        ),
        BooleanField(
            name='html_message',
            display_name='HTML Message',
            description='Check to send as an HTML formatted message'
        ),
        BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                'When enabled, this will skip notification of resources which '
                'are already marked noncompliant by this bot.'
            )
        )
    ]
)
def send_delayed_email(bot, settings, matches, non_matches):
    message_subject = Template(settings.get('message_subject', ''))
    message_body = Template(settings.get('message_body', ''))
    recipient_list = settings.get('recipient_list')
    recipient_jinja = Template(settings.get('recipient_jinja', ''))
    html_message = settings.get('html_message', False)
    skip_duplicates = settings.get('skip_duplicates', False)
    separator = settings.get('separator') or ';'

    # When migrating from an old config to the new config with these
    # options, they can come back as None
    raw_tag_keys = settings.get('recipient_tag_keys', [])
    if raw_tag_keys is None:
        raw_tag_keys = []
    tag_keys = [item.lower() for item in raw_tag_keys]

    raw_badge_keys = settings.get('recipient_badge_keys', [])
    if raw_badge_keys is None:
        raw_badge_keys = []
    badge_keys = [item for item in raw_badge_keys]

    db = DivvyCloudGatewayORM()

    # Get a list of noncompliant resource IDs
    noncompliant_resource_ids = []
    if skip_duplicates:
        noncompliant_resource_ids = get_noncompliant_resource_ids(
            db, bot.resource_id
        )

    with ScheduledEventTracker() as context:
        for resource in non_matches:
            context.remove_scheduled_bot_events(
                bot, str(resource.resource_id)
            )

        for chunk in misc.chunks(matches, 250):
            value_mapping = get_email_tags_for_resources(
                db, chunk, tag_keys, separator
            ) if tag_keys else {}
            badge_mapping = get_email_badges_for_resources(
                db, chunk, badge_keys, separator
            ) if badge_keys else {}
            for resource in chunk:
                # Stubs event so templates are backwards compatable
                event = BotEvent(
                    'hookpoint', resource, bot.bot_id, bot.name,
                    bot.resource_id, bot.insight_id, bot.insight_name,
                    bot.severity, bot.description
                )

                if skip_duplicates and str(resource.resource_id) in noncompliant_resource_ids:
                    continue

                # Conditionally extend recipient list with the value(s)
                # from the supplied tag keys.
                processed_recipients = set()
                resource_id_str = str(resource.resource_id)
                if resource_id_str in value_mapping:
                    for value in value_mapping[resource_id_str]:
                        processed_recipients.add(value)
                if resource.organization_service_id in badge_mapping:
                    for badge in badge_mapping[resource.organization_service_id]:
                        processed_recipients.add(badge)

                try:
                    jinja_recipient = recipient_jinja.render(event=event, resource=resource)
                except Exception as e:
                    jinja_recipient = "Error parsing message subject [{0}]".format(e)
                    logger.exception(jinja_recipient)

                values = separate_emails(jinja_recipient, separator=';')

                for value in values:
                    if is_valid_email(value):
                        processed_recipients.add(value)

                # Convert to JSON to store in the event action_data
                try:
                    email_subject = message_subject.render(event=event, resource=resource)
                except Exception as e:
                    email_subject = "Error parsing message subject [{0}]".format(e)
                    logger.exception(email_subject)

                try:
                    email_body = message_body.render(event=event, resource=resource)
                except Exception as e:
                    email_body = "Error parsing message body [{0}]".format(e)
                    logger.exception(email_body)

                action_data = {
                    'subject': email_subject,
                    'body': email_body,
                    'from_email': None,
                    'recipient_list': recipient_list + list(processed_recipients),
                    'html_message': html_message
                }

                context.schedule_bot_event(
                    bot,
                    resource,
                    'Event scheduled by bot.',  # TODO: More descriptive message
                    'divvy.send_email',
                    schedule_hours_from_now(settings.get('hours', 24)),
                    action_data=json.dumps(action_data)
                )


class DelayedMailJinjaRecipient(PluginJob):
    worker_name = 'DelayedMailJinjaRecipient'


def run(self):
    pass


def __repr__(self):
    return "DelayedMailJinjaRecipient()"


def register():
    args = {}
    Router.add_job(DelayedMailJinjaRecipient, args=args)


def unregister():
    pass


def load():
    registry.load()
