from sqlalchemy import and_, not_, or_, func

from DivvyDb.DbObjects import ResourceTag, CollectionData
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyDb.QueryFilters.tag import RESOURCES_SUPPORTING_TAGS
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    BooleanField, FieldOptions, MultiSelectionField
)


default_filters_author = 'Yanolja'

REQUIRED_TAGS = {
    'team': [],
    'security': [],
    'name': [],
    'environment': []
}


@QueryRegistry.register(
    query_id='yanolja.filter.tag_policy_standard',
    name='Yanolja Tagging Standard Violations',
    description=(
        'Match resources which are in violation of the Yanolja tagging standard'
    ),
    supported_resources=RESOURCES_SUPPORTING_TAGS,
    supports_common=True,
    version='21.2'
)
def tag_policy_standard(query, db_cls, settings_config):
    session = query.session
    required_args = ()
    for key in REQUIRED_TAGS:
        required_args = required_args + ('$."' + key + '"',)

    clauses = or_(
        not_(func.JSON_CONTAINS_PATH(func.LOWER(ResourceTag.tags), 'all', *required_args)),
        not_(
            func.LOWER(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                ResourceTag.tags, '$."environment"'
            ))).in_(
                session.query(CollectionData.value)
            )
        ),
        not_(
            func.LOWER(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                ResourceTag.tags, '$."team"'
            ))).in_(
                session.query(CollectionData.value)
            )
        ),
        not_(
            func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                func.LOWER(ResourceTag.tags), '$."security"'
            ))) > 2
        ),
        not_(
            func.LENGTH(func.JSON_UNQUOTE(func.JSON_EXTRACT(
                func.LOWER(ResourceTag.tags), '$."name"'
            ))) > 2
        )
    )

    subq = session.query(ResourceTag.resource_id).filter(clauses)
    tags_subq = session.query(ResourceTag.resource_id)

    return query.filter(or_(
        db_cls.resource_id.in_(subq),
        db_cls.resource_id.notin_(tags_subq)
    ))


def load():
    pass
