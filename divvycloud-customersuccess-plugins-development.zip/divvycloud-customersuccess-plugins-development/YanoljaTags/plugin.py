from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    """
    Information about email sending plugin.
    """
    version = '2.0'
    last_updated_date = '2021-02-26'
    author = 'DivvyCloud Inc.'
    nickname = 'Yanolja Tag Filters'
    default_language_description = 'Filters for tag compliance'
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


def load():
    pass


def unload():
    pass
