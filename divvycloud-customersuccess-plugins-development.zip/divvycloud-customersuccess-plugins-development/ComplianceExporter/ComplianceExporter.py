import boto3
import json
import logging
import os
from datetime import date, datetime
from sqlalchemy import and_

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DbObjects.resources import NotificationTopic
from DivvyDb.DbObjects.insights import InsightPack
from DivvyDb.DbObjects.insights.back_office_insight import BackOfficeInsight, BackOfficeInsightResource
from DivvyDb.DbObjects.insights.insight import Insight, CustomInsightResource
from DivvyDb.DbObjects import OrganizationService, ResourceCommonData, Organization
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyResource.resource_matrix import ResourceMatrix
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('ComplianceExporter')
SNS_TOPIC_ARN = os.environ.get('COMPLIANCE_EXPORTER_TOPIC')
INSTANCE_PROFILE_SUPPORT = os.environ.get('INSTANCE_PROFILE_SUPPORT')

# Modify this to include the target Insight pack(s)
PACK_NAMES = ['Expedia-Insights']

class ComplianceExporter(PluginJob):
    worker_name = 'ComplianceExporter'

    def get_insight_results(self, backoffice_insight_ids, custom_insight_ids):
        with NewSession(DivvyCloudGatewayORM) as session:
            for resource_cls in [
                BackOfficeInsightResource, CustomInsightResource
            ]:
                insight_cls = BackOfficeInsight
                if resource_cls == CustomInsightResource:
                    insight_cls = Insight

                query = session.query(
                    resource_cls.resource_type,
                    resource_cls.identified_at,
                    resource_cls.organization_service_id,
                    resource_cls.state,
                    resource_cls.last_modified,
                    ResourceCommonData.provider_id,
                    ResourceCommonData.resource_id,
                    ResourceCommonData.region_name,
                    ResourceCommonData.namespace_id,
                    ResourceCommonData.name,
                    ResourceCommonData.pending_delete,
                    insight_cls.insight_id,
                    insight_cls.name.label('insight_name'),
                    insight_cls.description.label('insight_description'),
                    OrganizationService.name.label('account'),
                    OrganizationService.account_id,
                    OrganizationService.cloud_type_id
                ).outerjoin(
                    ResourceCommonData, and_(
                        resource_cls.auto_id == ResourceCommonData.auto_id,
                        resource_cls.resource_type == ResourceCommonData.resource_type
                    )
                ).filter(
                    resource_cls.insight_id == insight_cls.insight_id
                ).filter(
                    resource_cls.organization_service_id == OrganizationService.organization_service_id
                ).filter(
                    resource_cls.state.in_([0, 1])
                ).filter(
                    OrganizationService.organization_id == Organization.organization_id
                ).filter(
                    Organization.simulated.is_(False)
                )

                if insight_cls == BackOfficeInsight:
                    source = 'backoffice'
                    if backoffice_insight_ids is not None:
                        query = query.filter(insight_cls.insight_id.in_(
                            backoffice_insight_ids
                        ))
                elif insight_cls == Insight:
                    source = 'custom'
                    if custom_insight_ids is not None:
                        query = query.filter(insight_cls.insight_id.in_(
                            custom_insight_ids
                        ))

                logger.info('Processing %s records for %s Insight findings', query.count(), source)
                for row in query:
                    yield row

    def publish_message(self, backend, message):
        try:
            logger.info('Publishing message for %s', message['insight_name'])
            message_attributes = {
                'insight_name': {
                    'DataType': 'String',
                    'StringValue': message['insight_name']
                },
                'insight_id': {
                    'DataType': 'String',
                    'StringValue': message['insight_id']
                }
            }
            if INSTANCE_PROFILE_SUPPORT:
                region = SNS_TOPIC_ARN.split(':')[3]

                boto3.client('sns', region_name=region).publish(
                    TopicArn=SNS_TOPIC_ARN,
                    Message=json.dumps(message),
                    MessageAttributes=message_attributes
                )

            else:
                backend.PublishToCloudTopic(
                    cloud_topic=SNS_TOPIC_ARN,
                    message=json.dumps(message),
                    msg_attr_key='insight_name',
                    msg_attr_value=message_attributes,
                    use_application_role=False
                )
        except Exception:
            logger.exception('Unable to publish message')

    def get_topic_from_db(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                NotificationTopic.organization_service_id,
                NotificationTopic.region_name
            ).filter(
                NotificationTopic.arn == SNS_TOPIC_ARN
            ).first()

    def get_packs_from_db(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            for row in session.query(
                InsightPack.name,
                InsightPack.description,
                InsightPack.backoffice,
                InsightPack.custom
            ).filter(
                InsightPack.name.in_(PACK_NAMES)
            ):
                yield row

    def execute_scan(self):
        if not SNS_TOPIC_ARN:
            raise Warning(
                'Please supply the notification topic environment variable'
            )

        # Lookup the frontend for this ARN
        topic = self.get_topic_from_db()
        if not topic:
            raise Warning(
                'Unable to lookup the topic for the supplied ARN'
            )

        # Get optional packs for scoping
        backoffice_insight_ids = set()
        custom_insight_ids = set()
        if PACK_NAMES:
            for pack in self.get_packs_from_db():
                if(pack.backoffice is not None):
                    for insight_id in pack.backoffice:
                        backoffice_insight_ids.add(insight_id)
                if(pack.custom is not None):
                    for insight_id in pack.custom:
                        custom_insight_ids.add(insight_id)


        if not backoffice_insight_ids and not custom_insight_ids:
            raise ValueError('Supplied pack appears empty')

        frontend = get_cloud_type_by_organization_service_id(
            topic.organization_service_id
        )
        backend = frontend.get_cloud_gw(region_name=topic.region_name)
        total_resources = 0
        for row in self.get_insight_results(
            backoffice_insight_ids, custom_insight_ids
        ):
            if row.state == 0:
                state = 'NONCOMPLIANT'
            else:
                state = 'COMPLIANT'

            msg = '' # Placeholder for future use as context-specific information in the message
             # Build messsage
            if(row.pending_delete == 0):  # don't send message for resources that are pending deletion
                message = {
                    'insight_id': str(row.insight_id),
                    'insight_name': row.insight_name,
                    'insight_description': row.insight_description,
                    'divvy_resource_type': row.resource_type,
                    'divvy_resource_id': row.resource_id,
                    'provider_resource_type': getattr(ResourceMatrix, row.cloud_type_id)().get(row.resource_type, ''),
                    'provider_id': row.provider_id,
                    'state': state,
                    'account_name': row.account,
                    'account_id': row.account_id,
                    'cloud_type_id': row.cloud_type_id,
                    'region_name': row.region_name,
                    'resource_name': row.name,
                    'arn': row.namespace_id,
                    'last_modified': str(row.last_modified),
                    'event_time': str(datetime.utcnow().replace(microsecond=0)),
                    'message': msg
                }
                total_resources += 1
                self.publish_message(backend, message)
        return total_resources

    def run(self):
        try:
            total_resources = self.execute_scan()
            logger.info('Scan finished. %s resources processed', total_resources)
        except Exception:
            logger.exception('Error during scan')

    def __repr__(self):
        return "ComplianceExporter()"


def register():
    args = {}
    Router.add_job(ComplianceExporter, args=args)
    scheduler_client.add_calendar_job(
        job=ComplianceExporter.__name__,
        args=args,
        schedule=schedule.Daily(schedule.TimeOfDay(hour=0, minute=0)) #UTC
    )


def unregister():
    pass

def load():
    pass

