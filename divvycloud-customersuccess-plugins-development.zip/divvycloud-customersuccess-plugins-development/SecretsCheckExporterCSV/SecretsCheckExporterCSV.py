import boto3
import json
import logging
import os
from collections import defaultdict
from datetime import datetime
from sqlalchemy import and_
from botocore.exceptions import ClientError
import re

from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DbObjects.resources import StorageContainer
from DivvyDb.DbObjects import OrganizationService, ResourceTag, Organization, Secret
from DivvyDb.DivvyDb import NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router
from DivvyUtils.mail import send_email

logger = logging.getLogger('SecretsCheckExporterEmail')

# List of recipient addresses for the report email
EMAIL_RECIPIENTS = os.environ.get('SECRETS_CHECK_EXPORTER_EMAIL_RECIPIENTS')
EMAIL_BCC_RECIPIENTS = os.environ.get('SECRETS_CHECK_EXPORTER_EMAIL_BCC_RECIPIENTS')
# This is the org that has SMTP setup, org_id 1 is the default org
EMAIL_ORG_ID = 1

# path to the temp/scratch drive on the container or host
TMP_DIR_PATH = '/tmp'


SECRETS_NAME_REGEX_PATTERNS = {
    'RDS Master (rdsadm)': r"^/aws/rds/.*/master$",
    'Redshift Master (redshiftadm)': r"^/aws/redshift/.*/master$",
    'Service Account - IAG': r"^/iag/.*/iamadm$",
    'Service Account - EDBSS Services': r"^/edbss/.*/iamadm$",
    'Service Account - Guardium': r"^/guardm/.*/srvdbscn$",
    'Service Account -  Secrets Manager': r"^/secmgr/.*/secmgradm$",
    'EDBSS for Oracle 1': r"^/edbss/.*/edbar$",
    'EDBSS for Oracle 2': r"^/edbss/.*/feumon$",
    'Active Directory secrets': r".*/ad-fanniemaecom/.*",
    'LDAP accounts': r".*/ldap-fanniemaecom/.*",
    'PING - SSO ClientID/Secret': r".*/cidsec-ping/.*",
    'Cert Internal': r".*/cert/internal/.*",
    'Cert External': r".*/cert/external/public/.*",
    'App - Managed (Private /Storage Only) Secrets': r".*/app-managed/.*",
}

SECRETS_TAGS_STANDARD = {
    'AssetID': (),
    'AppCode': (),
    'ApplicationShortName': (),
    'CostCenter': (),
    'ResourceType': ('rds', 'redshift', 'ad', 'ldap', 'client_id_secret', 'cert', 'app-managed'),
    'SecretMgmt': ('secmgr', 'application', 'terraform'),
    'Replicate': ('yes', 'no', 'disabled'),
    'CreatedBy': ('IAG', 'Manual', 'UCD', 'SECMGR', 'SCAM'),
    'Lifecycle': (),
    'Environment': ('Development', 'Acceptance', 'CLVE', 'Contingency', 'Production', 'Sandbox', 'Test', 'ACNT'),
    'SystemOfRecordKey': (),
    'EnvironmentShortName': (),
}

SECRETS_TAGS_FOR_MATCHING_DISPLAY = [
    'Environment'
]

SECRETS_TAGS_REGEX_PATTERNS = {
    'SecretSpecVer': r"[0-9]+\.[0-9]+",
}

TAG_APP_SHORTNAME = 'ApplicationShortName'
TAG_ENV_SHORTNAME = 'EnvironmentShortName'

RESULTS_NAME_KEY = 'Secret name' #
RESULTS_ARN_KEY = 'Secret arn' #
RESULTS_NAME_MATCH_KEY = 'Name-match-case' #
RESULTS_TAG_MATCH_KEY = 'Tags-matched'
RESULTS_TAGVALUE_MATCH_KEY = 'Tags-matched-with-values'
RESULTS_TAG_UNMATCH_KEY = 'Tags-unmatched'
RESULTS_ORGSERVICE_KEY = 'organization_service'
RESULTS_COMPLIANCE = 'Overall Compliance' #
RESULTS_NAME_COMPLIANCE = 'Name Compliance' #
RESULTS_TAG_COMPLIANCE = 'Tag Compliance'#
RESULTS_ORGSERVICE_NAME = 'Cloud Name' #
RESULTS_ORGSERVICE_ACCOUNT_ID = 'Cloud Account ID' #
RESULTS_ORGSERVICE_CLOUDTYPE_ID = 'Cloud Type' #
RESULTS_ORGSERVICE_ORG_ID = 'Organization ID'
RESULTS_ORG_NAME = 'Organization Name' #

OUTPUT_SEPARATOR = ','
RESULTS_SIMPLE_KEYS = [
    RESULTS_NAME_KEY,
    RESULTS_ARN_KEY,
    RESULTS_COMPLIANCE,
    RESULTS_NAME_COMPLIANCE,
    RESULTS_TAG_COMPLIANCE,
    RESULTS_ORGSERVICE_CLOUDTYPE_ID,
    RESULTS_ORGSERVICE_ACCOUNT_ID,
    RESULTS_ORGSERVICE_NAME,
    RESULTS_ORG_NAME
]

class SecretsCheckExporterEmail(PluginJob):
    worker_name = 'SecretsCheckExporterEmail'

    def get_secrets(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            query = session.query(
                Secret.name,
                Secret.resource_id,
                Secret.description,
                Secret.arn,
                Secret.organization_service_id,
            )
            for row in query:
                yield row

    def execute_scan(self):
        total_resources = 0
        filename = 'divvycloud-secret-check-' + datetime.utcnow().replace(microsecond=0).isoformat() + '.csv'
        filename_path = TMP_DIR_PATH + '/%s' % filename
        results_dynamic_keys = []
        results_dynamic_keys.append(RESULTS_NAME_MATCH_KEY)
        # Create the union of all tags that are expected, converted to lowercase
        tagset_combined = SECRETS_TAGS_STANDARD.keys() | SECRETS_TAGS_REGEX_PATTERNS.keys()
        tagset_combined_lower = set()        
        for tag in tagset_combined:
            tagset_combined_lower.add(tag.lower())

        # rebuild the standard tags dict to be all lowercase
        secret_tags_standard_lowercase = defaultdict(set)
        for tagkey in SECRETS_TAGS_STANDARD.keys():
            tag_expected_values_raw = SECRETS_TAGS_STANDARD.get(tagkey)
            tagkey_lower = tagkey.lower()
            for expected_value in tag_expected_values_raw:
                if expected_value is not None:
                    secret_tags_standard_lowercase[tagkey_lower].add(expected_value.lower())
        
        secrets_tags_regex_patterns_lower = {}
        for tagkey in SECRETS_TAGS_REGEX_PATTERNS:
            secrets_tags_regex_patterns_lower[tagkey.lower()] = SECRETS_TAGS_REGEX_PATTERNS[tagkey].lower()

        secrets_tags_for_matching_display_lower = []
        for tagkey in SECRETS_TAGS_FOR_MATCHING_DISPLAY:
            secrets_tags_for_matching_display_lower.append(tagkey.lower())

        taglist = list(tagset_combined)
        taglist_lower = []
        for tag in taglist:
            taglist_lower.append(tag.lower())

        taglist_with_val = []
        for tag in taglist:
            tag_header = tag + ' Value'
            taglist_with_val.append(tag_header)

        f = open(filename_path, "w")

        #Print the header
        f.write(OUTPUT_SEPARATOR.join(RESULTS_SIMPLE_KEYS))
        f.write(OUTPUT_SEPARATOR)
        f.write(OUTPUT_SEPARATOR.join(results_dynamic_keys))
        f.write(OUTPUT_SEPARATOR)
        f.write(OUTPUT_SEPARATOR.join(SECRETS_TAGS_FOR_MATCHING_DISPLAY))
        f.write(OUTPUT_SEPARATOR)
        f.write(OUTPUT_SEPARATOR.join(taglist_with_val))
        f.write('\n')




        for row in self.get_secrets():
            name_lower = row.name.lower()
            results = {key:[] for key in [
                RESULTS_COMPLIANCE, 
                RESULTS_NAME_COMPLIANCE,
                RESULTS_TAG_COMPLIANCE,
                RESULTS_NAME_KEY,
                RESULTS_ARN_KEY,
                RESULTS_ORGSERVICE_KEY,
                RESULTS_NAME_MATCH_KEY,
                RESULTS_TAG_MATCH_KEY,
                RESULTS_TAGVALUE_MATCH_KEY,
                RESULTS_TAG_UNMATCH_KEY,
                RESULTS_ORGSERVICE_NAME,
                RESULTS_ORGSERVICE_ACCOUNT_ID,
                RESULTS_ORGSERVICE_CLOUDTYPE_ID,
                RESULTS_ORG_NAME]}
            tags_values_dict = {}
            matched_tags = set()
            env_shortname = None
            app_shortname = None
            with NewSession(DivvyCloudGatewayORM) as session:
                tags_query = session.query(
                    ResourceTag.tags,
                ).filter(
                    ResourceTag.resource_id == row.resource_id
                )
                for tag_row in tags_query:
                    match = False
                    tags = tag_row.tags
                    for tag_raw, value_raw in tags.items():
                        tag = tag_raw.lower()
                        value = None
                        if value_raw is not None:
                            value = value_raw.lower()
                        tags_values_dict[tag] = value
                        if tag == TAG_APP_SHORTNAME.lower():
                            app_shortname = value
                        if tag == TAG_ENV_SHORTNAME.lower():
                            env_shortname = value
                        if tag in tagset_combined_lower:
                            # check the tag and see if it matches any requirements
                            # Standard tags
                            tag_expected_values = secret_tags_standard_lowercase.get(tag)

                            if tag_expected_values is None or len(tag_expected_values) == 0:
                                # The tag can have any value, but can't be empty
                                if value is not None and value != "":
                                    match = True
                            elif value is not None and value in tag_expected_values:
                                # The tag has a required set of values, and this tag matches
                                match = True

                            #Check the tags with regex rules for matching values
                            tag_expected_pattern = secrets_tags_regex_patterns_lower.get(tag)
                            if tag_expected_pattern is not None and len(tag_expected_pattern) > 0:
                                # This tag has a regex matching pattern, test it
                                val_re = re.compile(tag_expected_pattern)
                                if val_re.match(value) is not None:
                                    match = True
                            if match is True:
                                # This tag matched, add it to the set of matching tags
                                matched_tags.add(tag)
                            if value is None or value == "":
                                tags_values_dict[tag] = 'NULL'
                            

                # Now we can see if there are any unmatched tags
                unmatched_tags = tagset_combined_lower.difference(matched_tags)
                for tag in matched_tags:
                    results[RESULTS_TAG_MATCH_KEY].append(tag)
                for tag in unmatched_tags:
                    results[RESULTS_TAG_UNMATCH_KEY].append(tag)

                tags_found = tags_values_dict.keys()
                tags_missing = tagset_combined_lower.difference(tags_found)
                for tag in tags_missing:
                    tags_values_dict[tag] = 'MISSING'


                # Check the static regex-based name patterns
                for case, pattern in SECRETS_NAME_REGEX_PATTERNS.items():
                    # Try  regex match on the name
                    re_pattern  = re.compile(pattern.lower())
                    if re_pattern.match(row.name.lower()) is not None:
                        results[RESULTS_NAME_MATCH_KEY].append(case)

                # Check the dynamic patterns
                if app_shortname is not None:
                    dynamic_name = app_shortname + '_dbo'
                    if dynamic_name == name_lower:
                        results[RESULTS_NAME_MATCH_KEY].append('dynamic_app_dbo')
                    if env_shortname is not None:
                        dynamic_name = app_shortname + '_' + env_shortname
                        if dynamic_name == name_lower:
                            results[RESULTS_NAME_MATCH_KEY].append('dynamic_app_env')

                if len(results[RESULTS_NAME_MATCH_KEY]) != 0:
                    results[RESULTS_NAME_COMPLIANCE] = 'compliant'
                else:
                    results[RESULTS_NAME_COMPLIANCE] ='non-compliant'

                if len(results[RESULTS_TAG_UNMATCH_KEY]) == 0:
                    results[RESULTS_TAG_COMPLIANCE] = 'compliant'
                else:
                    results[RESULTS_TAG_COMPLIANCE] ='non-compliant'

                if len(results[RESULTS_NAME_MATCH_KEY]) != 0 and len(results[RESULTS_TAG_UNMATCH_KEY]) == 0:
                    results[RESULTS_COMPLIANCE] = 'Compliant'
                else:
                    results[RESULTS_COMPLIANCE] = 'Non-compliant'

                results[RESULTS_NAME_KEY] = row.name
                results[RESULTS_ARN_KEY] = row.arn
                # get cloud name, and org name for result
                results[RESULTS_ORGSERVICE_KEY] = row.organization_service_id
                # Get orgservice params

                orgservice = session.query(
                    OrganizationService.name,
                    OrganizationService.account_id,
                    OrganizationService.cloud_type_id,
                    OrganizationService.organization_id,
                ).filter(
                    OrganizationService.organization_service_id == row.organization_service_id
                ).first()
                if orgservice is not None:
                    results[RESULTS_ORGSERVICE_NAME] = orgservice.name
                    results[RESULTS_ORGSERVICE_ACCOUNT_ID] = orgservice.account_id
                    results[RESULTS_ORGSERVICE_CLOUDTYPE_ID] = orgservice.cloud_type_id
                    org = session.query(
                        Organization.name,
                    ).filter(
                        Organization.organization_id == orgservice.organization_id
                    ).first()
                    if org is not None:
                        results[RESULTS_ORG_NAME] = org.name


            # Create a json result
            #row_result = json.dumps(results)
            #f.write(row_result + '\n')
            total_resources += 1
            values = []
            scratchlist = []
            for field in RESULTS_SIMPLE_KEYS:
                val = results.get(field)
                if val is None:
                    values.append('')
                else:
                    valstr = (
                        '"{0}"'.format(str(val))
                    )
                    values.append(valstr)
            scratchlist = results.get(RESULTS_NAME_MATCH_KEY)
            if scratchlist is None:
                values.append('')
            else:
                valstr = '"' + ','.join(scratchlist) + '"'
                values.append(valstr)
            for tag in secrets_tags_for_matching_display_lower:
                if tag in matched_tags:
                    values.append('matched')
                else:
                    values.append('unmatched')
            for tag in taglist_lower:
                tagval = tags_values_dict.get(tag)
                values.append(tagval or '')

            f.write(OUTPUT_SEPARATOR.join(values))
            f.write('\n')

        f.close()

        # Convert the EMAIL_RECIPIENTS and EMAIL_BCC_RECIPIENTS string to lists
        email_recipients_list = []
        email_bcc_recipients_list = []
        if EMAIL_RECIPIENTS is not None:
            email_recipients_list = EMAIL_RECIPIENTS.split(',')
        if EMAIL_BCC_RECIPIENTS is not None:
            email_bcc_recipients_list = EMAIL_BCC_RECIPIENTS.split(',')

        # Send the file as an email attachment
        send_email(
            subject='Divvycloud: secrets name and tag compliance report',
            message='Report is attached',
            from_email='noreply@divvycloud.com',
            recipient_list=email_recipients_list,
            bcc_list=email_bcc_recipients_list,
            organization_id=EMAIL_ORG_ID,
            files=[filename_path]
        )

        # clean up temp files
        os.remove(filename_path)
        return total_resources



    def run(self):
        try:
            logger.info('starting Secrets Check')
            total_resources = self.execute_scan()
            logger.info('Scan finished. %s secrets processed', total_resources)
        except Exception:
            logger.exception('Error during scan')

    def __repr__(self):
        return "SecretsCheckExporterEmail()"


def register():
    args = {}
    Router.add_job(SecretsCheckExporterEmail, args=args)
    scheduler_client.add_calendar_job(
        job=SecretsCheckExporterEmail.__name__,
        args=args,
        schedule=schedule.Daily(schedule.TimeOfDay(hour=0, minute=0))
        #schedule = schedule.Hourly(minute_of_hour=0)

    )


def unregister():
    pass


def load():
    pass
