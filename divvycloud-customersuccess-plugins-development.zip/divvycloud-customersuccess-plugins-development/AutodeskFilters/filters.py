from sqlalchemy import func, DECIMAL

from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    FieldOptions, OperatorField, FloatField, Op
)
from DivvyUtils.misc import bool_evaluate


default_filters_author = 'DivvyCloud'


@QueryRegistry.register(
    query_id='custom.query.database_engine_version',
    name='Database Engine Version Threshold',
    description=(
        'Identify database instances/clusters by the database engine version. '
        'Note that this filter will only filter on the major/minor version and '
        'will not get the maintenance build. For example you can filter on '
        '5.7, but not 5.7.29.'
    ),
    supported_clouds=[],
    supported_resources=[
        ResourceType.DATABASE_CLUSTER,
        ResourceType.DATABASE_INSTANCE,
    ],
    settings_config=[
        FloatField(
            name='version',
            display_name='Version',
            description=(
                'Enter the desired version. Note that this must be a float '
                '(e.g. 5.7)'
            ),
            options=[FieldOptions.REQUIRED]
        ),
        OperatorField(
            name='operator',
            display_name='Operator',
            description='Select the desired operator',
            choices=[Op.LT, Op.EQ, Op.GT],
            options=[FieldOptions.REQUIRED]
        )
    ],
    version='20.5'
)
def database_engine_version(query, db_cls, settings_config):
    version = settings_config['version']
    op = settings_config['operator']
    column = func.cast(db_cls.engine_version, DECIMAL(10, 1))
    if op == 'eq':
        query = query.filter(column == version)
    else:
        query = query.filter(bool_evaluate(column, op, version))

    return query


def load():
    pass
