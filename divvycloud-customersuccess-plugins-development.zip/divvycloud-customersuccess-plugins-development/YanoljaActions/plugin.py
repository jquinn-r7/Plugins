"""
Main plugin module for custom actions
"""
from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    """
    Information about this plugin
    """
    version = '1.0'
    last_updated_date = '2018-03-27'
    author = 'Yanolja'
    nickname = 'Yanolja Custom Actions'
    default_language_description = 'Contains custom actions for Bots'
    category = 'Actions'
    managed = False


def load():
    pass

def unload():
    pass
