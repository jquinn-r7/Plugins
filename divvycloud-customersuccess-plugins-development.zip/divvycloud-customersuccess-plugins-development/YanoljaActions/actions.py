from collections import defaultdict
from jinja2 import Template
from sqlalchemy import func

from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyBotfactory.event import BotEvent
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb import DivvyDbObjects
from DivvyBotfactory.integrations.slack import send_slack, WEBHOOK_URL
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyUtils.field_definition import (
    FieldOptions, StringField, Jinja2TextField, BooleanField
)


registry = BotFactoryRegistryWrapper()

@registry.action(
    uid='custom.action.publish_to_dynamic_slack_channel',
    name='Publish to Slack Channel Using Owner Lookup',
    bulk_action=True,
    description=(
        'Send a message to a particular Slack channel based on the ownership '
        'tag.'
    ),
    author='Yanolja',
    supported_resources=[],
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_CHINA,
        CloudType.AMAZON_WEB_SERVICES_GOV
    ],
    settings_config=[
        StringField(
            name='tag_key',
            display_name='Tag Key',
            options=FieldOptions.REQUIRED,
            description='The owner tag key. Note that this is case sensitive.'
        ),
        StringField(
            name='collection_name',
            display_name='Data Collection Name',
            options=FieldOptions.REQUIRED,
            description='The Data Collection to use as the Slack channel lookup'
        ),
        StringField(
            name='fallback_channel',
            display_name='Fallback Channel',
            options=FieldOptions.REQUIRED,
            description=(
                'A fallback channel to send the message to in the event that '
                'the channel cannot be identified.'
            )
        ),
        StringField(
            name='username',
            display_name='Username',
            description='The username to send the message as (Slack supports up to 50 characters)'
        ),
        Jinja2TextField(
            name='message',
            display_name='Message Body',
            description='Contents of the message. Jinja2 formatting is allowed.',
            options=[FieldOptions.JINJA_PREVIEW]
        ),
        BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                'When enabled, this will skip notification of resources which '
                'are already marked noncompliant by this bot.'
            )
        )
    ]
)
def publish_to_dynamic_slack_channel(bot, settings, matches, _non_matches):
    db = DivvyCloudGatewayORM()

    resource_ids = [item.resource_id for item in matches]
    channel_mapping = {}
    channel_tag_value_mapping = {}
    default_channel = settings['fallback_channel']
    skip_duplicates = settings.get('skip_duplicates', False)
    organization = bot.get_organization()
    prop = organization.get_resource().get_setting(WEBHOOK_URL)
    webhook_url = prop.value if prop is not None else None
    if webhook_url:
        # Build channel mapping. This is a little messy due to the DataCollection
        # structure.
        db_obj = db.session.query(
            DivvyDbObjects.Collection.id
        ).filter(
            DivvyDbObjects.Collection.name == settings['collection_name']
        ).first()

        if db_obj:
            collection_id = str(db_obj.id)
            for row in db.session.query(
                DivvyDbObjects.CollectionData.value,
                DivvyDbObjects.CollectionData.description
            ).filter(
                func.JSON_CONTAINS_PATH(
                    DivvyDbObjects.CollectionData.description, 'all', '$."' + collection_id + '"'
                )
            ):
                channel_tag_value_mapping[row.value] = row.description[collection_id]

            # Get the tag value
            for row in db.session.query(
                DivvyDbObjects.ResourceTag.resource_id,
                DivvyDbObjects.ResourceTag.tags
            ).filter(
                DivvyDbObjects.ResourceTag.resource_id.in_(resource_ids)
            ).filter(
                func.JSON_CONTAINS_PATH(
                    DivvyDbObjects.ResourceTag.tags, 'all', '$."' + settings['tag_key'] + '"'
                )
            ):
                slack_channel = channel_tag_value_mapping.get(
                    row.tags.get(settings['tag_key'])
                )
                if slack_channel:
                    channel_mapping[row.resource_id] = slack_channel

        for resource in matches:
            # Stubs event so templates are backwards compatable
            event = BotEvent(
                'hookpoint', resource, bot.bot_id, bot.name, bot.resource_id,
                bot.insight_id, bot.insight_name
            )
            if skip_duplicates and str(resource.resource_id) in noncompliant_resource_ids:
                continue

            # Get slack settings for this resource
            message_raw = Template(settings.get('message', 'Error: message not configured'))
            try:
                message = message_raw.render(event=event, resource=resource)
            except Exception as e:
                message = "Unable to parse message [{0}]".format(e)
                logger.exception(message)

            send_slack(
                url=webhook_url,
                channel=channel_mapping.get(
                    str(resource.resource_id), default_channel
                ),
                user=settings['username'],
                message=message
            )

@registry.action(
    uid='custom.action.publish_summary_to_dynamic_slack_channel',
    name='Publish Summary Message To Slack Channel Using Owner Lookup',
    bulk_action=True,
    description=(
        'Send a summary message to a particular Slack channel based on the '
        'ownership tag. Note that this action groups messages by account.'
    ),
    author='Yanolja',
    supported_resources=[],
    supported_clouds=[],
    settings_config=[
        StringField(
            name='tag_key',
            display_name='Tag Key',
            options=FieldOptions.REQUIRED,
            description='The owner tag key. Note that this is case sensitive.'
        ),
        StringField(
            name='collection_name',
            display_name='Data Collection Name',
            options=FieldOptions.REQUIRED,
            description='The Data Collection to use as the Slack channel lookup'
        ),
        StringField(
            name='fallback_channel',
            display_name='Fallback Channel',
            options=FieldOptions.REQUIRED,
            description=(
                'A fallback channel to send the message to in the event that '
                'the channel cannot be identified.'
            )
        ),
        StringField(
            name='username',
            display_name='Username',
            description='The username to send the message as (Slack supports up to 50 characters)'
        ),
        BooleanField(
            name='skip_duplicates',
            display_name='Skip Previously Identified Resources',
            description=(
                'When enabled, this will skip notification of resources which '
                'are already marked noncompliant by this bot.'
            )
        )
    ]
)
def publish_summary_to_dynamic_slack_channel(
    bot, settings, matches, _non_matches
):
    db = DivvyCloudGatewayORM()

    resource_ids = [item.resource_id for item in matches]
    channel_mapping = {}
    channel_tag_value_mapping = {}
    default_channel = settings['fallback_channel']
    skip_duplicates = settings.get('skip_duplicates', False)
    organization = bot.get_organization()
    prop = organization.get_resource().get_setting(WEBHOOK_URL)
    webhook_url = prop.value if prop is not None else None
    account_mapping = dict(db.session.query(
        DivvyDbObjects.OrganizationService.organization_service_id,
        DivvyDbObjects.OrganizationService.name
    ))
    message_mapping = defaultdict(lambda: defaultdict(list))
    if webhook_url:
        # Build channel mapping. This is a little messy due to the DataCollection
        # structure.
        db_obj = db.session.query(
            DivvyDbObjects.Collection.id
        ).filter(
            DivvyDbObjects.Collection.name == settings['collection_name']
        ).first()

        if db_obj:
            collection_id = str(db_obj.id)
            for row in db.session.query(
                DivvyDbObjects.CollectionData.value,
                DivvyDbObjects.CollectionData.description
            ).filter(
                func.JSON_CONTAINS_PATH(
                    DivvyDbObjects.CollectionData.description, 'all', '$."' + collection_id + '"'
                )
            ):
                channel_tag_value_mapping[row.value] = row.description[collection_id]

            # Get the tag value
            for row in db.session.query(
                DivvyDbObjects.ResourceTag.resource_id,
                DivvyDbObjects.ResourceTag.tags
            ).filter(
                DivvyDbObjects.ResourceTag.resource_id.in_(resource_ids)
            ).filter(
                func.JSON_CONTAINS_PATH(
                    DivvyDbObjects.ResourceTag.tags, 'all', '$."' + settings['tag_key'] + '"'
                )
            ):
                slack_channel = channel_tag_value_mapping.get(
                    row.tags.get(settings['tag_key'])
                )
                if slack_channel:
                    channel_mapping[row.resource_id] = slack_channel

        for resource in matches:
            if skip_duplicates and str(resource.resource_id) in noncompliant_resource_ids:
                continue

            channel = channel_mapping.get(
                str(resource.resource_id), default_channel
            )
            message_mapping[channel][resource.organization_service_id].append(
                resource.get_resource_name()
            )

        for channel in message_mapping.keys():
            message = '\n'
            for org_svc_id in message_mapping[channel].keys():
                message += '''
\n*Account*: `{0}`\n
*Name*: `{1}`'''.format(
    account_mapping.get(org_svc_id),
    ', '.join(message_mapping[channel][org_svc_id])
)
            if message:
                send_slack(
                    url=webhook_url,
                    channel=channel,
                    user=settings['username'],
                    message=message
                )

def load():
    registry.load()