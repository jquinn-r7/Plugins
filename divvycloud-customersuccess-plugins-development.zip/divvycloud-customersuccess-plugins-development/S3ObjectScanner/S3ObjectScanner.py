import boto3
import csv
import jinja2
import json
import logging
import os
from datetime import date, datetime, timedelta
from sqlalchemy import and_

from DivvyApp.app_constants import Constants
from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb import DbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DivvyDb import SharedSessionScope, NewSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils.mail import send_email
from worker.registry import Router

logger = logging.getLogger('S3ObjectScanner')


class S3ObjectScanner(PluginJob):
    worker_name = 'S3ObjectScanner'

    def __init__(
        self, bucket_names, email_recipients, organization_id, role=None,
        external_id=None
    ):
        super().__init__()
        self.bucket_names = bucket_names
        self.email_recipients = email_recipients
        self.organization_id = organization_id
        self.role = role
        self.external_id = external_id

    def get_buckets(self):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                DbObjects.StorageContainer.region_name,
                DbObjects.StorageContainer.name,
                DbObjects.StorageContainer.organization_service_id,
                DbObjects.OrganizationService.name.label('account_name')
            ).filter(
                DbObjects.OrganizationService.organization_service_id == DbObjects.StorageContainer.organization_service_id,
                DbObjects.OrganizationService.cloud_type_id.startswith('AWS'),
                DbObjects.OrganizationService.status.in_([0, 1]),
                DbObjects.StorageContainer.name.in_(self.bucket_names)
            ).all()

    def get_bucket_objects(self, client, bucket_name):
        try:
            paginator = client.get_paginator('list_objects_v2')
            response_iterator = paginator.paginate(Bucket=bucket_name)
            for page in response_iterator:
                for obj in page.get('Contents', []):
                    yield obj
        except Exception:
            """
            ClientError: An error occurred (AccessDenied) when calling the ListObjectsV2 operation: Access Denied
            """
            pass

    def process_object(self, client, bucket_name, object_key):
        public_objects = []
        unencrypted_objects = []
        try:
            for grant in client.get_object_acl(
                Bucket=bucket_name,
                Key=object_key
            )['Grants']:
                if grant.get('Grantee', {}).get('URI') in [
                    'http://acs.amazonaws.com/groups/global/AllUsers',
                    'http://acs.amazonaws.com/groups/global/AuthenticatedUsers'
                ]:
                    public_objects.append(object_key)

            if not client.head_object(Bucket=bucket_name, Key=object_key).get(
                'ServerSideEncryption'
            ):
                unencrypted_objects.append(object_key)
        except Exception:
            """
            ClientError: An error occurred (AccessDenied) when calling the ListObjectsV2 operation: Access Denied
            """
            logger.exception('Unable to read key')
            pass
        return public_objects, unencrypted_objects

    def process_notification(self, noncompliant_mapping):
        dir_name = os.path.abspath(os.path.dirname(__file__))
        html_template_path = os.path.join(
            dir_name + '/templates/bucket_report.html'
        )

        csv_filename = '/tmp/s3-object-report-{0}.csv'.format(
            datetime.utcnow().replace(microsecond=0, tzinfo=None)
        )
        headers = ['Bucket', 'Account', 'Object', 'Violation']
        with open(csv_filename, 'w', newline='', encoding='utf8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(headers)

            # Mutate mapping for now
            table_data = []
            for bucket_name, noncompliant_data in noncompliant_mapping.items():
                data = {'bucket_name': bucket_name}
                data.update(noncompliant_data)
                table_data.append(data)
                for obj in noncompliant_data['public_objects']:
                    writer.writerow([
                        bucket_name,
                        noncompliant_data['account_name'],
                        obj,
                        'Public Object'
                    ])

                for obj in noncompliant_data['unencrypted_objects']:
                    writer.writerow([
                        bucket_name,
                        noncompliant_data['account_name'],
                        obj,
                        'Unencrypted Object'
                    ])

        with open(html_template_path, 'r') as fp:
            email_template = fp.read()
            message_body = jinja2.Template(email_template)
            formatted_body = message_body.render(
                table_data=table_data,
                today=date.today().strftime('%B %d, %Y'),
                year=datetime.utcnow().year,
                main_logo=Constants.mapping['insight_pack_logo'],
                main_logo_alt=Constants.mapping['company_name'],
            )

            send_email(
                subject='S3 Object Report For {0}'.format(
                    date.today().strftime('%B %d, %Y')
                ),
                message=None,
                from_email='noreply@divvycloud.com',
                recipient_list=self.email_recipients,
                organization_id=self.organization_id,
                html_message=formatted_body,
                inline_css=True,
                files=[csv_filename]
            )


    def run(self):
        noncompliant_mapping = {}

        for bucket in self.get_buckets():
            if not self.role:
                frontend = get_cloud_type_by_organization_service_id(
                    bucket.organization_service_id
                )
                try:
                    backend = frontend.get_cloud_gw()
                except Exception:
                    # Bad account, let's continue
                    continue

                client = boto3.client(
                    's3',
                    aws_access_key_id=backend.auth_api_key,
                    aws_secret_access_key=backend.auth_secret,
                    aws_session_token=backend.session_token,
                    region_name=bucket.region_name
                )
            else:
                kwargs = {
                    'RoleArn': self.role,
                    'RoleSessionName': 'DivvyCloud'
                }

                if self.external_id:
                    kwargs['ExternalId'] = self.external_id

                response = boto3.client(
                    'sts',
                    region_name='us-east-1'
                ).assume_role(**kwargs)
                client = boto3.client(
                    's3',
                    aws_access_key_id=response['Credentials']['AccessKeyId'],
                    aws_secret_access_key=response['Credentials']['SecretAccessKey'],
                    aws_session_token=response['Credentials']['SessionToken'],
                    region_name=bucket.region_name
                )

            logger.info('Processing objects for %s', bucket.name)
            public_objects = []
            unencrypted_objects = []

            total_objects = 0
            start_time = datetime.utcnow()
            for obj in self.get_bucket_objects(client, bucket.name):
                public_objs, unencrypted_objs = self.process_object(
                    client, bucket.name, obj['Key']
                )
                public_objects.extend(public_objs)
                unencrypted_objects.extend(unencrypted_objs)
                total_objects += 1

            end_time = datetime.utcnow()
            if public_objects or unencrypted_objects:
                noncompliant_mapping[bucket.name] = {
                    'public_object_count': len(public_objects),
                    'public_objects': public_objects,
                    'unencrypted_object_count': len(unencrypted_objects),
                    'unencrypted_objects': unencrypted_objects,
                    'total_objects': total_objects,
                    'account_name': bucket.account_name,
                    'processing_time': (end_time - start_time).total_seconds()
                }

        self.process_notification(noncompliant_mapping)

    def __repr__(self):
        return "S3ObjectScanner()"


def register():
    Router.add_job(S3ObjectScanner, args={})


def unregister():
    pass

def load():
    pass