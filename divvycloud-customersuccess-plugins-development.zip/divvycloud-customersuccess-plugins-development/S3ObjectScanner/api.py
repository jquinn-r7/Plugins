import logging
from flask import request
from http import HTTPStatus

from DivvyBlueprints.v2 import Blueprint
from DivvyJobs.jobs import JobQueue
from DivvyPermissions.decorators import assert_session_is_organization_admin
from DivvyPlugins.plugin_helpers import (
    register_api_blueprint, unregister_api_blueprints
)
from DivvySession import DivvySession
from DivvyWorkers.queues import get_on_demand_queue

from .S3ObjectScanner import S3ObjectScanner

blueprint = Blueprint('object_scanner', __name__)
logger = logging.getLogger('ObjectScanner')


@blueprint.route('/scan', methods=['POST'])
@assert_session_is_organization_admin()
def scan_storage_containers():
    data = request.get_json()
    bucket_names = data.get('bucket_names')
    email_recipients = data.get('email_recipients')
    session = DivvySession.current_session()
    if not bucket_names or not email_recipients:
        raise Warning('Please supply an array of target bucket names and email email_recipients')

    logger.info('Executing S3 object scanning on %s buckets', len(bucket_names))
    with JobQueue(get_on_demand_queue()):
        S3ObjectScanner(bucket_names, email_recipients, session.user.organization_id).run_job()
    return '', HTTPStatus.OK, {}


def load():
    register_api_blueprint(blueprint)

def unload():
    unregister_api_blueprints()
