#!/usr/bin/env python
# -*- coding: utf-8 -*-
from . import S3ObjectScanner

processor_module_list = [S3ObjectScanner]

def register_processors():
    for module in processor_module_list:
        module.register()

def unregister_processors():
    for module in processor_module_list:
        module.unregister()