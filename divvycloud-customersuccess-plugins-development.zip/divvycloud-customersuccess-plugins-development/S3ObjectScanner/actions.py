from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb import DivvyDbObjects
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyJobs.jobs import JobQueue
from DivvyResource.resource_types import ResourceType
from DivvyWorkers.queues import get_on_demand_queue
from DivvyUtils.field_definition import (
    FieldOptions, StringField, MultiSelectionField
)

from .S3ObjectScanner import S3ObjectScanner

registry = BotFactoryRegistryWrapper()


@registry.action(
    uid='custom.action.execute_s3_object_scan',
    name='Scan S3 Objects For Encryption/Public Violations',
    bulk_action=True,
    description=(
        'Triggers an object scan on the target S3 buckets. Note that this will '
        'skip any S3 bucket with over 100,000 objects.'
    ),
    author='DivvyCloud',
    supported_resources=[ResourceType.STORAGE_CONTAINER],
    supported_clouds=[CloudType.AMAZON_WEB_SERVICES],
    settings_config=[
        MultiSelectionField(
            name='recipient_list',
            display_name='Recipient Emails',
            description='Who should receive the Email report?',
            choices=[],
            options=[FieldOptions.TAGS_EMAIL]
        ),
        StringField(
            name='role',
            display_name='Role Name (Optional)',
            description=(
                'The target role to assume. If not set, then the credentials '
                'associated with the account the bucket lives in will be used.'
            ),
            options=[],
        ),
        StringField(
            name='external_id',
            display_name='External ID (Optional)',
            description='The external ID to use with the assumed role.',
            options=[],
        )
    ]
)
def execute_s3_object_scan(bot, settings, matches, _non_matches):
    buckets = []
    email_recipients = settings['recipient_list']
    role = settings.get('role')
    external_id = settings.get('external_id')
    for resource in matches:
        if resource.object_count < 100000:
            buckets.append(resource.name)

    if buckets:
        with JobQueue(get_on_demand_queue()):
            S3ObjectScanner(
                buckets, email_recipients, bot.organization_id, role, external_id
            ).run_job()


def load():
    registry.load()
