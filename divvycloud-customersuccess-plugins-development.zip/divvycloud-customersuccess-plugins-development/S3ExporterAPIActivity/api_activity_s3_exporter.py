from DivvyApp.DivvyApp import DivvyApp
from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils.exception_reporting import report_exception
from DivvyDb.DivvyDb import SharedSessionScope
from scheduler import client, processors
from worker.registry import Router
from worker import const

import boto3
import botocore
from datetime import datetime, timedelta
from redlock import RedLock

import json
import logging


# Time between job executions, in hours.
JOB_RUN_FREQUENCY_IN_HOURS = 1
# S3 bucket in which API activity logs will be deposited. This plugin assumes
# that this bucket already exists.
# S3_BUCKET_NAME = 'divvycloud-ecc'
S3_BUCKET_NAME = '/target/bucket/name/here'
# Role to assume for reading from and writing to S3. If using
# InstanceAssumeRole for the DivvyCloud app, set this to None to use the app's
# role.
S3_ROLE_ARN = '/target/bucket/ARN/here'
# If true, we'll connect to the bucket with an encrypted client using default
# KMS encryption.
ENCRYPTED = True

logger = logging.getLogger(__name__)


class APIActivityS3Exporter(PluginJob):
    """
    A processor that, on execution, writes JSON equivalent to the output of the
    `/v2/apiactivity` endpoint to objects in an S3 bucket. These objects' keys
    follow a naming convention that acts as a checkpointing scheme so
    subsequent runs only request new activity from the database.
    """

    def __init__(self):
        super(APIActivityS3Exporter, self).__init__()

    def run(self):
        try:
            self._run()
        except Exception as e:
            import traceback
            traceback.print_exc()
            report_exception()
            raise

    def _run(self):
        # Use redis to prevent multiple instances of process from running at
        # the same time
        print('{}: inside run() method'.format(self.__class__.__name__))
        with RedLock(self.__class__.__name__, [DivvyApp().redis]):
            bucket = get_bucket_boto_resource(
                session_name='DivvyCloud{}Plugin'.format(self.__class__.__name__)
            )

            greatest_id_in_bucket = get_greatest_tracked_id_from_bucket(bucket)
            api_activity = get_api_activity(
                start_id=greatest_id_in_bucket + 1 if greatest_id_in_bucket else None
            )

            # If there's no new activity, we're done here
            if not api_activity:
                return

            # If there's new activity, write it. Largest ID is encoded in the
            # file name, to be picked up by
            # `get_greatest_tracked_id_from_bucket`
            new_greatest_id = max(x['activity_id'] for x in api_activity)
            extra_put_kwargs = ({'ServerSideEncryption': 'aws:kms'}
                                if ENCRYPTED
                                else {})
            bucket.put_object(
                Key='divvycloud-api/{}.and-earlier-activity.json'.format(new_greatest_id),
                Body=json.dumps(api_activity),
                **extra_put_kwargs
            )


def get_greatest_tracked_id_from_bucket(bucket):
    """
    Given a bucket whose object's keys all have the format

    <greatest-activity_id-in-this-file>.*

    return the greatest ID, or 0 if there are no objects in the bucket.
    """
    logger.info('Attempting to retrieve the latest tracked ID')
    # Get all bucket objects and look for this plugin's previous output files
    greatest_id_per_object = []
    for obj in bucket.objects.all():
        # first look for the "divvycloud-api" folder
        objkey_slash = obj.key.split('/')
        if (len(objkey_slash) > 1):
            if (objkey_slash[0] == "divvycloud-api"):
                # the folder exists. Now look for *.and-earlier-activity.json
                objkey_dot = objkey_slash[1].split('.')
                if (len(objkey_dot) > 2
                        and objkey_dot[1] == "and-earlier-activity"
                        and objkey_dot[2] == "json"):
                    greatest_id_per_object.append(int(objkey_dot[0]))


    if greatest_id_per_object:
        greatest_id_per_object.append(0)  # default starting point of 0
        return max(greatest_id_per_object)
    logger.info('Unable to identify the latest ID')
    return None


def get_bucket_boto_resource(session_name=None):
    if session_name is None:
        session_name = __name__
    # Use STS to assume a role that can write to a bucket
    sts_client = boto3.client('sts')
    current_account_dict = sts_client.get_caller_identity()
    current_account_number = current_account_dict.get('Account')
    print('{} has connection to STS with account {}'.format(APIActivityS3Exporter.__name__,
                                                            current_account_dict))

    if (not S3_ROLE_ARN) or (current_account_number in S3_ROLE_ARN):
        # can't assume your own role; just get the bucket
        return boto3.resource(
            's3', config=botocore.client.Config(signature_version='s3v4')
        ).Bucket(S3_BUCKET_NAME)
    else:
        print('Attempting to assume role to access S3 bucket with account {}'.format(
            current_account_dict
        ))
        sts_assumed_credentials = sts_client.assume_role(
            RoleArn=S3_ROLE_ARN, RoleSessionName=session_name
        )['Credentials']

        print('Successfully assumed role; getting bucket {}'.format(
            S3_BUCKET_NAME
        ))
        return boto3.resource(
            's3',
            aws_access_key_id=sts_assumed_credentials['AccessKeyId'],
            aws_secret_access_key=sts_assumed_credentials['SecretAccessKey'],
            aws_session_token=sts_assumed_credentials['SessionToken'],
            config=botocore.client.Config(signature_version='s3v4')
        ).Bucket(S3_BUCKET_NAME)


@SharedSessionScope(DivvyCloudGatewayORM)
def get_api_activity(start_id):
    """
    Produce a list of dictionaries logging all API activity, optionally
    restricted by `start_time` and `end_time`, which accept ISO 8601-formatted
    strings or `datetime.datetime` objects.

    This code is adapted from
    `DivvyBlueprints.v2.prototype.v2_api_activity.py`.
    """
    if start_id:
        logger.info('Attempting to get API activity beginning at ID %d', start_id)
    else:
        logger.info('Attempting to get API activity for the past 24 hours')
    query = DivvyCloudGatewayORM().session.query(
        DivvyDbObjects.ApiActivity,
        DivvyDbObjects.User.name.label('user_name'),
        DivvyDbObjects.Organization.name.label('organization_name')
    ).outerjoin(
        DivvyDbObjects.User,
        DivvyDbObjects.User.user_id == DivvyDbObjects.ApiActivity.user_id
    ).outerjoin(
        DivvyDbObjects.Organization,
        DivvyDbObjects.Organization.organization_id == DivvyDbObjects.ApiActivity.organization_id
    )

    if start_id:
        query = query.filter(DivvyDbObjects.ApiActivity.activity_id >= start_id)
    else:
        threshold = datetime.utcnow() - timedelta(days=1)
        query = query.filter(
            DivvyDbObjects.ApiActivity.access_time > threshold
        )
    return [
        {
            'activity_id': row.ApiActivity.activity_id,
            'access_time': str(row.ApiActivity.access_time),
            'remote_addr': row.ApiActivity.remote_addr,
            'path': row.ApiActivity.path,
            'method': row.ApiActivity.method,
            'data': row.ApiActivity.data,
            'status_code': row.ApiActivity.status_code,
            'user': row.user_name,
            'organization': row.organization_name
        }
        for row in query
    ]

def register():
    Router.add_job(APIActivityS3Exporter)
    job_name = APIActivityS3Exporter.__name__
    client.add_periodic_job(job_name,
                            args={},
                            interval=JOB_RUN_FREQUENCY_IN_HOURS * 60)
    # Hackily register for on-demand execution.
    processors.PROCESSOR_INDEX_BY_NAME[job_name] = {
        'job': job_name,
        'args': {},
        'schedule': JOB_RUN_FREQUENCY_IN_HOURS * 60,
        'queue': const.p0
    }

def unregister():
    pass

def load():
    pass
