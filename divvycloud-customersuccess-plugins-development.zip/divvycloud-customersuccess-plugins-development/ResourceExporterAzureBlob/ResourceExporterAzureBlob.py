import logging
import os
import io
from datetime import datetime
from azure.storage.blob import BlockBlobService

from DivvyDb import DivvyDbObjects
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM
from DivvyDb.DbObjects.resources import StorageContainer
from DivvyDb.DivvyDb import NewSession, SharedSession
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyUtils import schedule
from scheduler import client as scheduler_client
from worker.registry import Router

logger = logging.getLogger('ResourceExporterAzureBlob')

# Storage container name for storage of export files is taken from environment variable
# Note: the name is the container (bucket) name only, not the full ARN
STORAGE_CONTAINER_NAME = os.environ.get('RESOURCE_EXPORTER_AZURE_STORAGE_CONTAINER_NAME')

# path to the temp/scratch drive on the container or host
TMP_DIR_PATH = '/tmp'

# This manages the base list of fields that come from the primary query
BASE_FIELDS_LIST = [
    'provider_id',
    'name',
    'region_name',
    'resource_type',
    'creation_timestamp',
    'discovered_timestamp',
    'account_id',
    'account',
    'cloud_type_id',
]

# This is a list of resource tag keys that will be put in separate columns in the CSV
# (there is also a column that contains all tags)
TAGS_LIST = [
    # 'email',  # Example value
]


class ResourceExporterAzureBlob(PluginJob):
    worker_name = 'ResourceExporterAzureBlob'

    def get_resource_inventory(self):
        with SharedSession(DivvyCloudGatewayORM) as session:
            query = session.query(
                DivvyDbObjects.ResourceCommonData.provider_id,
                DivvyDbObjects.ResourceCommonData.name,
                DivvyDbObjects.ResourceCommonData.region_name,
                DivvyDbObjects.ResourceCommonData.resource_type,
                DivvyDbObjects.ResourceMatrix.name.label('cloud_resource_type'),
                DivvyDbObjects.ResourceCommonData.creation_timestamp,
                DivvyDbObjects.ResourceCommonData.discovered_timestamp,
                DivvyDbObjects.ResourceCommonData.pending_delete,
                DivvyDbObjects.OrganizationService.account_id,
                DivvyDbObjects.OrganizationService.name.label('account'),
                DivvyDbObjects.OrganizationService.cloud_type_id,
                DivvyDbObjects.ResourceCommonData.resource_id,
            ).filter(
                DivvyDbObjects.ResourceCommonData.organization_service_id
                == DivvyDbObjects.OrganizationService.organization_service_id,
                DivvyDbObjects.OrganizationService.cloud_type_id == DivvyDbObjects.ResourceMatrix.cloud_type_id,
                DivvyDbObjects.ResourceCommonData.resource_type == DivvyDbObjects.ResourceMatrix.resource_type,
            )
        for row in query:
            yield row

    def get_storage_container_from_db(self, name):
        with NewSession(DivvyCloudGatewayORM) as session:
            return session.query(
                StorageContainer.organization_service_id,
                StorageContainer.resource_id
            ).filter(
                StorageContainer.name == name
            ).first()

    # Upload file to storage container in Azure
    def UploadFileToStorageContainer(self, bucket, key, payload):
        """
        Uploads file to Azure Blob container
        """
        azure_account_name = os.getenv('RESOURCE_EXPORTER_AZURE_STORAGE_ACCOUNT_NAME')
        azure_account_key = os.getenv('RESOURCE_EXPORTER_AZURE_STORAGE_ACCOUNT_KEY')

        blob_service_client = BlockBlobService(
            account_name=azure_account_name,
            account_key=azure_account_key)
        blob_service_client.create_blob_from_stream(
            bucket, key, payload)
        # In case of errors, the Azure error response will go to log and the exception will
        # be caught in the run() method

    def execute_scan(self):
        if not STORAGE_CONTAINER_NAME:
            raise Warning(
                'Please supply the storage container name'
            )

        total_resources = 0
        # colons in filenames can cause them to be urlencoded on download, so swap colons for underscores
        filename = 'divvycloud-resources-' + str(datetime.utcnow().replace(microsecond=0).isoformat())\
            .replace(':', "-") + '.csv'

        filename_path = TMP_DIR_PATH + '/%s' % filename

        f = open(filename_path, "w")
        # Write header row to CSV
        f.write(','.join(BASE_FIELDS_LIST))
        if len(TAGS_LIST) > 0:
            f.write(',')
            f.write(','.join(TAGS_LIST))
        f.write(",tags\n")
        for row in self.get_resource_inventory(
        ):
            if row.pending_delete == 0:  # don't send message for resources that are pending deletion
                # see if the resource has tags
                row_dict = row._asdict()
                tags = {}
                with SharedSession(DivvyCloudGatewayORM) as session:
                    for inner_row in session.query(
                        DivvyDbObjects.ResourceTag.tags
                    ).filter(
                        DivvyDbObjects.ResourceTag.resource_id == row.resource_id
                    ):
                        tags.update(inner_row.tags)

                total_resources += 1
                values = []
                for field in BASE_FIELDS_LIST:
                    val = row_dict.get(field)
                    if val is None:
                        values.append('')
                    else:
                        valstr = (
                            '"{0}"'.format(str(val))
                        )
                        values.append(valstr)
                for tag_key in TAGS_LIST:
                    val = tags.get(tag_key)
                    if val is None:
                        values.append('')
                    else:
                        valstr = (
                            '"{0}"'.format(str(val))
                        )
                        values.append(valstr)

                f.write(','.join(values))
                f.write(',')
                f.write('"{0}"\n'.format(str(tags)))

        f.close()
        # reopen the file as binary read, for writing to blob
        f = open(filename_path, "rb")
        self.UploadFileToStorageContainer(STORAGE_CONTAINER_NAME, filename, f)
        f.close()

        # clean up temp files
        os.remove(filename_path)
        return total_resources

    def run(self):
        try:
            logger.info('starting inventory scan')
            total_resources = self.execute_scan()
            logger.info('Scan finished. %s resources processed', total_resources)
        except Exception:
            logger.exception('Error during scan')

    def __repr__(self):
        return "ResourceExporterAzureBlob()"


def register():
    args = {}
    Router.add_job(ResourceExporterAzureBlob, args=args)
    scheduler_client.add_calendar_job(
        job=ResourceExporterAzureBlob.__name__,
        args=args,
         schedule=schedule.Daily(schedule.TimeOfDay(hour=0, minute=0))
        #schedule=schedule.Hourly(minute_of_hour=30)

    )


def unregister():
    pass


def load():
    pass
