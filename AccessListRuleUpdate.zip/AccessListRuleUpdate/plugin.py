from DivvyPlugins.plugin_metadata import PluginMetadata

class metadata(PluginMetadata):
    """
    Information about this plugin
    """
    version = '1.0.0'
    last_updated_date = '2021-07-28'
    author = 'Divvy Cloud Corp.'
    nickname = 'Access List Rule Update'
    support_email = 'support@divvycloud.com'
    managed = False


def load():
    pass


def unload():
    pass
