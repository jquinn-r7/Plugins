from DivvyBotfactory.registry import BotFactoryRegistryWrapper
from DivvyDataModel.DivvyDataModel import Route
from DivvyDb import DivvyDbObjects
from DivvyDb.DbObjects.application import ResourceLink
from DivvyDb.DbObjects.resources.autoscalinggroup import AutoscalingGroup
from DivvyDb.DbObjects.resources.bigdatainstance import BigDataInstance
from DivvyDb.DbObjects.resources.bigdatainstance import BigDataInstance
from DivvyDb.DbObjects.resources.accesslist import ResourceAccessListRule, ResourceAccessList
import logging
import re
from email.utils import parseaddr
from DivvyCloudProviders.Common.Frontend.frontend import get_cloud_type_by_organization_service_id
from DivvyDb.DivvyCloudGatewayORM import DivvyCloudGatewayORM

from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry

from DivvyDb.DbObjects import ResourceTag,  Instance
from DivvyDb.QueryFilters.tag import RESOURCES_SUPPORTING_TAGS
from DivvyPlugins.plugin_jobs import PluginJob
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import FieldOptions, StringField
logger = logging.getLogger('AccessListRuleUpdate')
registry = BotFactoryRegistryWrapper()

# TODO see if we can use this    supports_common=True,


@QueryRegistry.register(
    query_id='custom.query.accesslist_rule_attached_to_instance',
    name='Access List Rule Attached to Instance',
    description='Returns AccessList rules that are attached to instances.',
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[ResourceType.RESOURCE_ACCESS_LIST_RULE],
    settings_config=[],
    version='21.4'
)
def filter_acesslist_rules_attached_to_instances(query, db_cls, settings_config):
    # query for all security groups
    # query for all instances
    # find parents of all security groups and filter for SG's that have parents in 
    #   the list of resource IDs for instances
    session = query.session
    instances_subq = session.query(Instance.resource_id)
    accesslist_subq = session.query(
        ResourceAccessList.resource_id
    )
    
    # Resources who have instances as parents
    instances_children_subq = session.query(
        ResourceLink.right_resource_id
    ).filter(
        ResourceLink.left_resource_id.in_(instances_subq)
    ).filter(
        ResourceLink.right_resource_id.in_(accesslist_subq)
    )
    
    instances_grandchildren_subq = session.query(
        ResourceAccessListRule.resource_id
    ).filter(
         ResourceAccessListRule.parent_resource_id.in_(instances_children_subq)
    )

    return query.filter(
        db_cls.resource_id.in_(instances_grandchildren_subq)
    )
 

@registry.action(
    uid='custom.action.update_accesslist_rule',
    name='Update a security group rule to modify its CIDR block',
    bulk_action=True,
    admin_only=True,
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[ResourceType.RESOURCE_ACCESS_LIST_RULE],
    description=(
            'Update a security group rule to modify its CIDR block'
    ),
    author='Rapid7',
    # TODO: Could make the target CIDR block a setting
    settings_config=[
        StringField('cidr', 'CIDR block', description='The new CIDR block for the rule. (eg: 192.168.1.0/24)',
            options=[
                FieldOptions.REQUIRED, 
                FieldOptions.UPDATE_FIELDS_ON_CHANGE])
    ]
)
def update_accesslist_rule(bot, settings, matches, _non_matches):

    # This will only run if matches exist. Avoid creation a ticket for
    # not matches and an empty matches.
    if not matches:
        return

    db = DivvyCloudGatewayORM()
    cidr_value = settings.get('cidr', '')

    updated_sg_set = set()

    for match in matches:
        frontend = get_cloud_type_by_organization_service_id(match.organization_service_id)
        # Because the validate_cidr_block is not a static method we can't check before entering this loop.
        # Since the same input is used for all, we let an error kill the bot action job
        frontend.validate_cidr_block(field = 'CIDR Block', value = cidr_value, network=None, exclude_prefix_limit=False)

        backend = frontend.get_cloud_gw()
        rule_parent_row = db.session.query(
            DivvyDbObjects.ResourceAccessList.resource_id,
            DivvyDbObjects.ResourceAccessList.access_list_type,
            DivvyDbObjects.ResourceAccessList.access_list_id
        ).filter(
            DivvyDbObjects.ResourceAccessList.resource_id == match.parent_resource_id
        ).first()
        
        # inspect the parent's 'access_list_type' to see if it's ACL or SG
        # enum('network_acl','instance_endpoint','firewall','security_group')
        access_list_type = rule_parent_row.access_list_type
        if access_list_type == 'security_group':
            if match.parent_resource_id not in updated_sg_set:
                # Create the new rule, but if we've already had a match in this security group during this evaluation, 
                # we'll get an error if we try to create a duplicate. This can happen if the bot's filters
                # can match on multiple rules in the same SG
                try:
                    backend.CreateSecurityGroupRules(
                        rule_parent_row.access_list_id, 
                        match.ip_protocol, 
                        match.destination_from_port, 
                        match.destination_to_port,
                        network_list=[cidr_value],  
                        user_group_id_list=None, 
                        prefix_list=None,  
                        direction='ingress',
                        user_comment='Created by InsightCloudSec bot action'  # Could note that this was created by the bot action?
                    )
                    updated_sg_set.add(match.parent_resource_id)
                    logger.info('Created new rule in {}'.format(match.parent_resource_id))
                except Exception as e:
                    logger.info('Error creating new rule in {}: {}'.format(match.parent_resource_id, e))

            # delete the old rule
            try:
                backend. DeleteSecurityGroupRule(match.resource_id, direction='ingress')
                logger.info('Deleted rule {} from {}'.format(match.resource_id, match.parent_resource_id))
            except Exception as e:
                # Exception will log its own failure info
                logger.info('Error deleting rule {} from {}: {}'.format(match.resource_id, match.parent_resource_id, e))


class AccessListRuleUpdate(PluginJob):
    worker_name = 'AccessListRuleUpdate'


def run(self):
    pass


def __repr__(self):
    return "AccessListRuleUpdate()"


def register():
    args = {}
    Route.add_job(AccessListRuleUpdate, args=args)


def unregister():
    pass


def load():
    registry.load()


