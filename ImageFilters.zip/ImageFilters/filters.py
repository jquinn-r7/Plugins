from sqlalchemy import or_, and_
from sqlalchemy.orm import aliased

from DivvyDb import DivvyDbObjects as dbo
from DivvyDb.QueryFilters.cloud_types import CloudType
from DivvyDb.QueryFilters.registry import QueryRegistry
from DivvyResource.resource_types import ResourceType
from DivvyUtils.field_definition import (
    FieldOptions, MultiSelectionField, BooleanField, StringField
)


default_filters_author = 'InsightCloudSec'


@QueryRegistry.register(
    query_id='custom.query.resource_running_unapproved_image',
    name='Resource Running Unapproved Image',
    description=(
        'Identify instance/autoscaling group resources that are using '
        'unapproved images.'
    ),
    supported_clouds=[
        CloudType.AMAZON_WEB_SERVICES,
        CloudType.AMAZON_WEB_SERVICES_GOV,
        CloudType.AMAZON_WEB_SERVICES_CHINA
    ],
    supported_resources=[
        ResourceType.AUTOSCALING_LAUNCH_CONFIGURATION,
        ResourceType.INSTANCE
    ],
    settings_config=[
        MultiSelectionField(
            choices=[],
            name='account_ids',
            display_name='Shared Account IDs',
            description=(
                'Enter one or more account IDs that the image can be shared '
                'from. If the underlying image is shared from an account '
                'outside of this list it will in violation.'
            ),
            options=[FieldOptions.REQUIRED, FieldOptions.TAGS]
        ),
        StringField(
            name='image_name_regexp',
            display_name='Image Name Regular Expression',
            description=(
                'Use this optional field to input a regular expression pattern '
                'to validate the image name with.'
            ),
        ),
    ],
    version='21.5'
)
def resource_running_unapproved_image(query, db_cls, settings_config):
    SI = aliased(dbo.SharedImage)
    session = query.session
    account_ids = settings_config['account_ids']
    image_ids = settings_config.get('image_ids', [])
    image_name_regexp = settings_config.get('image_name_regexp', [])

    join_cols = and_(
        db_cls.image_id == SI.image_id,
        SI.owner_id.in_(account_ids)
    )
    if image_name_regexp:
        join_cols.append(SI.name.op('regexp')(r'%s' % image_name_regexp))

    return query.outerjoin(SI, join_cols).filter(SI.image_id.is_(None))


def load():
    pass
