from DivvyPlugins.plugin_metadata import PluginMetadata


class metadata(PluginMetadata):
    version = '1.0'
    last_updated_date = '2021-03-09'
    author = 'DivvyCloud Inc.'
    nickname = 'Subnet Query Filters'
    default_language_description = 'Costar Custom filters'
    support_email = 'support@divvycloud.com'
    support_url = 'http://support.divvycloud.com'
    main_url = 'http://www.divvycloud.com'
    managed = True


def load():
    pass


def unload():
    pass
